"use client";
import React from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  SectionLabel,
  GlowDot,
  GlobalStyles,
  colors,
} from "../../components/VS";
import {
  Activity,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  Clock,
  DollarSign,
  Shield,
  TrendingDown,
  TrendingUp,
  Users,
  Zap,
  AlertTriangle,
  Brain,
  Heart,
} from "lucide-react";

function Navbar() {
  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        background: "rgba(2,6,23,0.95)",
        backdropFilter: "blur(20px)",
        borderBottom: `1px solid ${colors.border}`,
        padding: "0 32px",
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 64,
        }}
      >
        <a
          href="/"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            textDecoration: "none",
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={18} color="#000" />
          </div>
          <span
            style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
          >
            VitalSync
          </span>
        </a>
        <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
          {[
            ["Home", "/"],
            ["About", "/about"],
            ["Features", "/features"],
            ["Login", "/login"],
          ].map(([l, h]) => (
            <a
              key={l}
              href={h}
              style={{
                color: colors.textSecondary,
                fontSize: 14,
                textDecoration: "none",
                fontWeight: 500,
              }}
            >
              {l}
            </a>
          ))}
          <CyanButton
            variant="solid"
            size="sm"
            onClick={() => (window.location.href = "/register")}
          >
            Hospital Integration
          </CyanButton>
        </div>
      </div>
    </nav>
  );
}

export default function WhyPage() {
  const metrics = [
    {
      value: "58%",
      label: "Faster Triage",
      sub: "Average time from check-in to doctor review",
      color: colors.cyan,
      icon: <Clock size={20} />,
    },
    {
      value: "94.7%",
      label: "AI Accuracy",
      sub: "Clinical decision support precision rate",
      color: colors.green,
      icon: <Brain size={20} />,
    },
    {
      value: "$2.1M",
      label: "Annual Savings",
      sub: "Per 300-bed hospital, average Year 1",
      color: colors.amber,
      icon: <DollarSign size={20} />,
    },
    {
      value: "73%",
      label: "Error Reduction",
      sub: "Medical errors prevented via history checks",
      color: colors.green,
      icon: <Shield size={20} />,
    },
    {
      value: "41%",
      label: "Less ICU Overflow",
      sub: "Through predictive capacity management",
      color: colors.cyan,
      icon: <BarChart3 size={20} />,
    },
    {
      value: "6.2hrs",
      label: "Nurse Time Saved",
      sub: "Per shift via automated documentation",
      color: colors.amber,
      icon: <Users size={20} />,
    },
  ];

  const roiPoints = [
    {
      icon: <Zap size={18} color={colors.cyan} />,
      title: "Reduce Triage Time by 58%",
      desc: "From 22-minute average to under 10 minutes. Patients identified, history loaded, and queue populated before they reach the doctor.",
    },
    {
      icon: <AlertTriangle size={18} color={colors.red} />,
      title: "Reduce Medical Error Risk by 73%",
      desc: "Every clinical decision is cross-checked against full patient history. Allergies, drug interactions, chronic conditions — instantly visible.",
    },
    {
      icon: <TrendingUp size={18} color={colors.green} />,
      title: "Faster Emergency Escalation",
      desc: "Critical patients are flagged by AI before the doctor sees them. Escalation protocols trigger automatically based on symptom severity scoring.",
    },
    {
      icon: <BarChart3 size={18} color={colors.amber} />,
      title: "Reduced ICU Overload by 41%",
      desc: "Predictive capacity management identifies surge patterns 48 hours in advance. Staff accordingly. Avoid the chaos before it begins.",
    },
    {
      icon: <Shield size={18} color={colors.green} />,
      title: "Audit-Grade Documentation",
      desc: "Every clinical action timestamped, versioned, and logged. HIPAA audit requests completed in minutes, not weeks.",
    },
    {
      icon: <DollarSign size={18} color={colors.cyan} />,
      title: "Lower Downstream Hospital Costs",
      desc: "Readmission rates drop 34% when doctors have complete patient context. Preventable readmissions cost US hospitals $26B annually.",
    },
    {
      icon: <Heart size={18} color={colors.red} />,
      title: "Improved Patient Outcomes",
      desc: "Mortality rates in partner ERs dropped an average of 12% in Year 1. The data is unambiguous — complete context saves lives.",
    },
    {
      icon: <Clock size={18} color={colors.cyan} />,
      title: "Faster Emergency Response Speed",
      desc: "EMS teams receive patient history before arrival. ER teams are briefed and ready. Response time advantage: 4.2 minutes average.",
    },
    {
      icon: <Users size={18} color={colors.green} />,
      title: "Reduced Nurse Workload",
      desc: "Automated documentation saves 6.2 hours per nurse per shift. Better staff retention. Lower agency costs. Happier teams.",
    },
    {
      icon: <TrendingDown size={18} color={colors.amber} />,
      title: "Operational Efficiency Uplift",
      desc: "Hospital operational overhead drops 19% in Year 2. Fewer duplicate tests, faster discharges, and better resource utilization.",
    },
  ];

  const compliance = [
    {
      label: "HIPAA Compliant",
      desc: "Full BAA-ready. Privacy rule, security rule, and breach notification rule compliance built in.",
    },
    {
      label: "SOC 2 Type II",
      desc: "Independently audited. Trust Service Criteria: Security, Availability, Confidentiality.",
    },
    {
      label: "HL7 FHIR R4",
      desc: "Standards-based interoperability with existing EHR systems including Epic, Cerner, and Meditech.",
    },
    {
      label: "ISO 27001",
      desc: "Information security management system certified. Risk-based approach to data protection.",
    },
  ];

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
      }}
    >
      <GlobalStyles />
      <Navbar />

      {/* Hero */}
      <section
        style={{
          padding: "140px 32px 80px",
          textAlign: "center",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "20%",
            left: "50%",
            transform: "translateX(-50%)",
            width: 800,
            height: 400,
            borderRadius: "50%",
            background:
              "radial-gradient(circle,rgba(6,182,212,0.07) 0%,transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <Badge color="amber" dot>
            B2B ROI Report
          </Badge>
          <h1
            style={{
              color: colors.textPrimary,
              fontSize: "clamp(36px,5vw,68px)",
              fontWeight: 900,
              margin: "24px 0 20px",
              letterSpacing: "-0.035em",
              lineHeight: 1.06,
            }}
          >
            Why <span style={{ color: colors.cyan }}>340+ Hospitals</span>
            <br />
            Choose VitalSync
          </h1>
          <p
            style={{
              color: colors.textSecondary,
              fontSize: 18,
              lineHeight: 1.75,
              maxWidth: 580,
              margin: "0 auto 40px",
            }}
          >
            This isn't a pitch deck. These are measured outcomes from real
            hospital deployments. The ROI is quantifiable, the timeline is 90
            days.
          </p>
          <div
            style={{
              display: "flex",
              gap: 16,
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <CyanButton
              variant="solid"
              size="lg"
              onClick={() => (window.location.href = "/register")}
            >
              Request Integration <ArrowRight size={18} />
            </CyanButton>
            <CyanButton
              variant="outline"
              size="lg"
              onClick={() => (window.location.href = "/about")}
            >
              Read Our Story
            </CyanButton>
          </div>
        </div>
      </section>

      {/* Key Metrics */}
      <section style={{ padding: "0 32px 80px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3,1fr)",
              gap: 20,
            }}
            className="metrics-grid"
          >
            {metrics.map((m, i) => (
              <GlassCard key={i} style={{ padding: "28px 24px" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "flex-start",
                    justifyContent: "space-between",
                  }}
                >
                  <div>
                    <div
                      style={{
                        color: m.color,
                        fontSize: "clamp(32px,4vw,48px)",
                        fontWeight: 900,
                        letterSpacing: "-0.03em",
                        lineHeight: 1,
                      }}
                    >
                      {m.value}
                    </div>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 16,
                        fontWeight: 700,
                        margin: "8px 0 4px",
                      }}
                    >
                      {m.label}
                    </div>
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 12,
                        lineHeight: 1.5,
                      }}
                    >
                      {m.sub}
                    </div>
                  </div>
                  <div
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 11,
                      background: `${m.color}15`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: m.color,
                      flexShrink: 0,
                    }}
                  >
                    {m.icon}
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:860px){.metrics-grid{grid-template-columns:repeat(2,1fr)!important}}@media(max-width:540px){.metrics-grid{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>

      {/* ROI Breakdown */}
      <section
        style={{
          padding: "80px 32px",
          borderTop: `1px solid ${colors.border}`,
        }}
      >
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <SectionLabel>Clinical & Financial ROI</SectionLabel>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(26px,3vw,44px)",
                fontWeight: 800,
                margin: "16px 0 0",
                letterSpacing: "-0.025em",
              }}
            >
              Every Dollar Has a Return.
            </h2>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2,1fr)",
              gap: 16,
            }}
            className="roi-grid"
          >
            {roiPoints.map((r, i) => (
              <GlassCard key={i} hover style={{ padding: "22px 20px" }}>
                <div
                  style={{ display: "flex", gap: 14, alignItems: "flex-start" }}
                >
                  <div
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: 9,
                      background: "rgba(255,255,255,0.04)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {r.icon}
                  </div>
                  <div>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 14,
                        fontWeight: 700,
                        marginBottom: 6,
                      }}
                    >
                      {r.title}
                    </div>
                    <div
                      style={{
                        color: colors.textSecondary,
                        fontSize: 13,
                        lineHeight: 1.6,
                      }}
                    >
                      {r.desc}
                    </div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:700px){.roi-grid{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>

      {/* Compliance */}
      <section
        style={{
          padding: "80px 32px",
          borderTop: `1px solid ${colors.border}`,
        }}
      >
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <SectionLabel>Compliance & Security</SectionLabel>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(26px,3vw,44px)",
                fontWeight: 800,
                margin: "16px 0 0",
                letterSpacing: "-0.025em",
              }}
            >
              Enterprise-Grade.{" "}
              <span style={{ color: colors.green }}>Regulation-Ready.</span>
            </h2>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: 20,
            }}
            className="comp-grid"
          >
            {compliance.map((c, i) => (
              <GlassCard
                key={i}
                style={{
                  padding: "24px 20px",
                  border: `1px solid rgba(16,185,129,0.2)`,
                }}
              >
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 9,
                    background: "rgba(16,185,129,0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 14,
                  }}
                >
                  <CheckCircle2 size={18} color={colors.green} />
                </div>
                <div
                  style={{
                    color: colors.green,
                    fontSize: 13,
                    fontWeight: 700,
                    marginBottom: 8,
                  }}
                >
                  {c.label}
                </div>
                <div
                  style={{
                    color: colors.textSecondary,
                    fontSize: 12,
                    lineHeight: 1.6,
                  }}
                >
                  {c.desc}
                </div>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:860px){.comp-grid{grid-template-columns:repeat(2,1fr)!important}}@media(max-width:500px){.comp-grid{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "80px 32px 120px" }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <GlassCard
            style={{
              padding: "64px",
              textAlign: "center",
              border: `1px solid rgba(6,182,212,0.2)`,
            }}
          >
            <Badge color="amber" dot>
              90-Day ROI Guarantee
            </Badge>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(24px,3vw,44px)",
                fontWeight: 900,
                margin: "20px 0 16px",
                letterSpacing: "-0.025em",
              }}
            >
              Measurable Impact in 90 Days or We Work for Free
            </h2>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 16,
                lineHeight: 1.7,
                margin: "0 0 36px",
              }}
            >
              We're so confident in VitalSync's clinical and financial impact
              that we offer a full performance guarantee on every enterprise
              contract. If your hospital doesn't see measurable triage
              improvement in 90 days, we continue at no charge.
            </p>
            <div
              style={{
                display: "flex",
                gap: 16,
                justifyContent: "center",
                flexWrap: "wrap",
              }}
            >
              <CyanButton
                variant="solid"
                size="xl"
                onClick={() => (window.location.href = "/register")}
              >
                Start Hospital Integration
              </CyanButton>
              <CyanButton
                variant="outline"
                size="xl"
                onClick={() => (window.location.href = "/about")}
              >
                Meet the Team
              </CyanButton>
            </div>
          </GlassCard>
        </div>
      </section>
    </div>
  );
}
