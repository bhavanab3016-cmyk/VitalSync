import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  try {
    if (id) {
      const patients =
        await sql`SELECT * FROM patients WHERE national_id = ${id}`;
      return Response.json(patients[0] || null);
    }
    const patients = await sql`SELECT * FROM patients ORDER BY created_at DESC`;
    return Response.json(patients);
  } catch (error) {
    console.error("Error fetching patients:", error);
    return Response.json(
      { error: "Failed to fetch patients" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const { national_id, full_name, email, dob, gender } = await request.json();

    // Check if exists
    const existing =
      await sql`SELECT national_id FROM patients WHERE national_id = ${national_id}`;
    if (existing.length > 0) {
      return Response.json(
        { error: "National ID already exists" },
        { status: 400 },
      );
    }

    const [patient] = await sql`
      INSERT INTO patients (national_id, full_name, email, dob, gender)
      VALUES (${national_id}, ${full_name}, ${email}, ${dob}, ${gender})
      RETURNING *
    `;
    return Response.json(patient);
  } catch (error) {
    console.error("Error creating patient:", error);
    return Response.json(
      { error: "Failed to create patient" },
      { status: 500 },
    );
  }
}
