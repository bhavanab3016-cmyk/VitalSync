import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const patientId = searchParams.get("patientId");

  try {
    const visits = await sql`
      SELECT created_at as date, 'Hospital Visit' as type, symptoms as description, status
      FROM hospital_visits 
      WHERE patient_id = ${patientId}
    `;

    const records = await sql`
      SELECT created_at as date, 'Clinical Record' as type, diagnosis as description, prescriptions as detail
      FROM clinical_records 
      WHERE patient_id = ${patientId}
    `;

    const timeline = [...visits, ...records].sort(
      (a, b) => new Date(b.date) - new Date(a.date),
    );

    return Response.json(timeline);
  } catch (error) {
    console.error("Timeline error:", error);
    return Response.json(
      { error: "Failed to fetch timeline" },
      { status: 500 },
    );
  }
}
