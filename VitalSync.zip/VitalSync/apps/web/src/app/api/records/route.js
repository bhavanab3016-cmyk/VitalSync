import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const patientId = searchParams.get("patientId");

  try {
    if (patientId) {
      const records = await sql`
        SELECT * FROM clinical_records 
        WHERE patient_id = ${patientId} 
        ORDER BY created_at DESC
      `;
      return Response.json(records);
    }
    return Response.json({ error: "Patient ID required" }, { status: 400 });
  } catch (error) {
    console.error("Error fetching records:", error);
    return Response.json({ error: "Failed to fetch records" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { patient_id, visit_id, diagnosis, prescriptions } =
      await request.json();

    return await sql.transaction(async (txn) => {
      const [record] = await txn`
        INSERT INTO clinical_records (patient_id, visit_id, diagnosis, prescriptions)
        VALUES (${patient_id}, ${visit_id}, ${diagnosis}, ${prescriptions})
        RETURNING *
      `;

      if (visit_id) {
        await txn`
          UPDATE hospital_visits 
          SET status = 'completed'
          WHERE id = ${visit_id}
        `;
      }

      return Response.json(record);
    });
  } catch (error) {
    console.error("Error creating record:", error);
    return Response.json({ error: "Failed to create record" }, { status: 500 });
  }
}
