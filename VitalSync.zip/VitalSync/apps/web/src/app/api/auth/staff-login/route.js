import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const { staff_id, password } = await request.json();
    const [staff] = await sql`
      SELECT * FROM hospital_staff 
      WHERE staff_id = ${staff_id} AND password = ${password}
    `;

    if (!staff) {
      return Response.json(
        { error: "Invalid staff ID or password" },
        { status: 401 },
      );
    }

    // In a real app, we'd return a JWT. For this demo, we'll return staff info.
    return Response.json(staff);
  } catch (error) {
    console.error("Login error:", error);
    return Response.json({ error: "Login failed" }, { status: 500 });
  }
}
