import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const patientId = searchParams.get("patientId");

  if (!patientId) {
    return Response.json({ error: "patientId is required" }, { status: 400 });
  }

  try {
    const [profile] = await sql`
      SELECT * FROM patient_profiles WHERE patient_id = ${patientId}
    `;
    return Response.json(profile || null);
  } catch (error) {
    console.error("Error fetching patient profile:", error);
    return Response.json({ error: "Failed to fetch profile" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      patient_id,
      blood_type,
      allergies,
      chronic_conditions,
      current_medications,
      last_hospitalization,
      insurance,
      emergency_contact,
      notes,
    } = body;

    const [profile] = await sql`
      INSERT INTO patient_profiles
        (patient_id, blood_type, allergies, chronic_conditions, current_medications, last_hospitalization, insurance, emergency_contact, notes)
      VALUES
        (${patient_id}, ${blood_type}, ${allergies}, ${chronic_conditions}, ${current_medications}, ${last_hospitalization}, ${insurance}, ${emergency_contact}, ${notes})
      ON CONFLICT (patient_id) DO UPDATE SET
        blood_type = EXCLUDED.blood_type,
        allergies = EXCLUDED.allergies,
        chronic_conditions = EXCLUDED.chronic_conditions,
        current_medications = EXCLUDED.current_medications,
        last_hospitalization = EXCLUDED.last_hospitalization,
        insurance = EXCLUDED.insurance,
        emergency_contact = EXCLUDED.emergency_contact,
        notes = EXCLUDED.notes,
        updated_at = now()
      RETURNING *
    `;
    return Response.json(profile);
  } catch (error) {
    console.error("Error saving profile:", error);
    return Response.json({ error: "Failed to save profile" }, { status: 500 });
  }
}
