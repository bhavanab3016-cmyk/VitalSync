import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");

  try {
    let query = sql`
      SELECT v.*, p.full_name, p.dob, p.gender 
      FROM hospital_visits v
      JOIN patients p ON v.patient_id = p.national_id
    `;

    if (status) {
      query = sql`
        SELECT v.*, p.full_name, p.dob, p.gender 
        FROM hospital_visits v
        JOIN patients p ON v.patient_id = p.national_id
        WHERE v.status = ${status}
        ORDER BY v.created_at ASC
      `;
    } else {
      query = sql`
        SELECT v.*, p.full_name, p.dob, p.gender 
        FROM hospital_visits v
        JOIN patients p ON v.patient_id = p.national_id
        ORDER BY v.created_at DESC
      `;
    }

    const visits = await query;
    return Response.json(visits);
  } catch (error) {
    console.error("Error fetching visits:", error);
    return Response.json({ error: "Failed to fetch visits" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { patient_id, symptoms } = await request.json();
    const [visit] = await sql`
      INSERT INTO hospital_visits (patient_id, symptoms, status)
      VALUES (${patient_id}, ${symptoms}, 'waiting')
      RETURNING *
    `;
    return Response.json(visit);
  } catch (error) {
    console.error("Error creating visit:", error);
    return Response.json({ error: "Failed to create visit" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const { id, status } = await request.json();
    const [visit] = await sql`
      UPDATE hospital_visits 
      SET status = ${status}
      WHERE id = ${id}
      RETURNING *
    `;
    return Response.json(visit);
  } catch (error) {
    console.error("Error updating visit:", error);
    return Response.json({ error: "Failed to update visit" }, { status: 500 });
  }
}
