import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const { patient_id, latitude, longitude } = await request.json();
    const [triage] = await sql`
      INSERT INTO global_triage (patient_id, latitude, longitude)
      VALUES (${patient_id}, ${latitude}, ${longitude})
      RETURNING *
    `;
    return Response.json(triage);
  } catch (error) {
    console.error("Triage error:", error);
    return Response.json({ error: "Failed to log triage" }, { status: 500 });
  }
}
