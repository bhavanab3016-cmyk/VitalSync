"use client";
import React, { useState, useEffect } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  NavLink,
  SectionLabel,
  GlowDot,
  GlobalStyles,
  colors,
} from "../components/VS";
import {
  Activity,
  AlertTriangle,
  Shield,
  Zap,
  Brain,
  Heart,
  Database,
  Clock,
  Users,
  ArrowRight,
  ChevronRight,
  Globe,
  Lock,
  BarChart3,
  Cpu,
  Radio,
  Wifi,
  TrendingUp,
  CheckCircle2,
  Menu,
  X,
  Star,
  Play,
  PhoneCall,
  Stethoscope,
  FileText,
  Monitor,
} from "lucide-react";

const ALERTS = [
  {
    id: 1,
    name: "Alex Rivera",
    id_num: "P-4821",
    severity: "critical",
    symptom: "Chest Pain + SOB",
    time: "2m ago",
    color: "#EF4444",
  },
  {
    id: 2,
    name: "Sarah Chen",
    id_num: "P-3302",
    severity: "moderate",
    symptom: "High Fever + Dizziness",
    time: "7m ago",
    color: "#F59E0B",
  },
  {
    id: 3,
    name: "Marcus Vane",
    id_num: "P-7190",
    severity: "stable",
    symptom: "Migraine + Nausea",
    time: "14m ago",
    color: "#10B981",
  },
  {
    id: 4,
    name: "Leila Hassan",
    id_num: "P-2051",
    severity: "critical",
    symptom: "Stroke Symptoms",
    time: "1m ago",
    color: "#EF4444",
  },
];
const METRICS = [
  { label: "Active Patients", value: "247", delta: "+12", color: colors.cyan },
  {
    label: "Avg Triage Time",
    value: "3.2m",
    delta: "-58%",
    color: colors.green,
  },
  {
    label: "ICU Capacity",
    value: "68%",
    delta: "optimal",
    color: colors.amber,
  },
  { label: "AI Accuracy", value: "99.1%", delta: "+0.3%", color: colors.cyan },
];

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);
  return (
    <>
      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 1000,
          background: scrolled ? "rgba(2,6,23,0.95)" : "transparent",
          backdropFilter: scrolled ? "blur(20px)" : "none",
          borderBottom: scrolled ? `1px solid ${colors.border}` : "none",
          transition: "all 0.4s ease",
          padding: "0 32px",
        }}
      >
        <div
          style={{
            maxWidth: 1280,
            margin: "0 auto",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            height: 68,
          }}
        >
          <a
            href="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              textDecoration: "none",
            }}
          >
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                background: "linear-gradient(135deg,#06B6D4,#0284C7)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 0 20px rgba(6,182,212,0.4)",
              }}
            >
              <Activity size={20} color="#000" />
            </div>
            <span
              style={{
                color: colors.textPrimary,
                fontWeight: 800,
                fontSize: 18,
                letterSpacing: "-0.02em",
              }}
            >
              VitalSync
            </span>
            <Badge color="cyan">AI-Powered</Badge>
          </a>
          <div
            style={{ display: "flex", alignItems: "center", gap: 32 }}
            className="nav-desktop"
          >
            <NavLink href="/about">About Us</NavLink>
            <NavLink href="/features">Services</NavLink>
            <NavLink href="/features">Products</NavLink>
            <NavLink href="/why">Hospital Integration</NavLink>
          </div>
          <div
            style={{ display: "flex", alignItems: "center", gap: 12 }}
            className="nav-desktop"
          >
            <CyanButton
              variant="ghost"
              size="sm"
              onClick={() => (window.location.href = "/login")}
            >
              Login
            </CyanButton>
            <CyanButton
              variant="solid"
              size="sm"
              onClick={() => (window.location.href = "/register")}
            >
              Register
            </CyanButton>
          </div>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            style={{
              background: "none",
              border: "none",
              color: colors.textPrimary,
              cursor: "pointer",
              display: "none",
            }}
            className="nav-mobile-btn"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        {mobileOpen && (
          <div
            style={{
              background: "rgba(2,6,23,0.99)",
              borderTop: `1px solid ${colors.border}`,
              padding: "20px 32px 28px",
              display: "flex",
              flexDirection: "column",
              gap: 18,
            }}
          >
            {[
              ["About Us", "/about"],
              ["Services", "/features"],
              ["Products", "/features"],
              ["Hospital Integration", "/why"],
            ].map(([l, h]) => (
              <a
                key={l}
                href={h}
                style={{
                  color: colors.textSecondary,
                  textDecoration: "none",
                  fontSize: 15,
                  fontWeight: 500,
                }}
              >
                {l}
              </a>
            ))}
            <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
              <CyanButton
                variant="outline"
                size="sm"
                onClick={() => (window.location.href = "/login")}
                full
              >
                Login
              </CyanButton>
              <CyanButton
                variant="solid"
                size="sm"
                onClick={() => (window.location.href = "/register")}
                full
              >
                Register
              </CyanButton>
            </div>
          </div>
        )}
      </nav>
      <style>{`@media(max-width:860px){.nav-desktop{display:none!important}.nav-mobile-btn{display:block!important}}`}</style>
    </>
  );
}

function LiveDashboard() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick((p) => p + 1), 2800);
    return () => clearInterval(t);
  }, []);
  return (
    <GlassCard
      style={{
        padding: 0,
        overflow: "hidden",
        border: `1px solid rgba(6,182,212,0.25)`,
        boxShadow: "0 0 80px rgba(6,182,212,0.12), 0 40px 80px rgba(0,0,0,0.6)",
        position: "relative",
      }}
    >
      <div
        style={{
          padding: "14px 18px",
          borderBottom: `1px solid ${colors.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ display: "flex", gap: 5 }}>
            {["#EF4444", "#F59E0B", "#10B981"].map((c) => (
              <div
                key={c}
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: "50%",
                  background: c,
                }}
              />
            ))}
          </div>
          <span
            style={{
              color: colors.textMuted,
              fontSize: 10,
              fontWeight: 600,
              letterSpacing: "0.08em",
            }}
          >
            VITALSYNC — LIVE COMMAND CENTER
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <GlowDot color={colors.green} size={7} />
          <span style={{ color: colors.green, fontSize: 10, fontWeight: 600 }}>
            REAL-TIME
          </span>
        </div>
      </div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4,1fr)",
          borderBottom: `1px solid ${colors.border}`,
        }}
      >
        {METRICS.map((m, i) => (
          <div
            key={i}
            style={{
              padding: "12px 14px",
              borderRight: i < 3 ? `1px solid ${colors.border}` : "none",
            }}
          >
            <div
              style={{
                color: colors.textMuted,
                fontSize: 9,
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.06em",
              }}
            >
              {m.label}
            </div>
            <div
              style={{
                color: m.color,
                fontSize: 20,
                fontWeight: 800,
                marginTop: 3,
              }}
            >
              {m.value}
            </div>
            <div
              style={{
                color: colors.green,
                fontSize: 9,
                fontWeight: 600,
                marginTop: 1,
              }}
            >
              {m.delta}
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding: "10px 0" }}>
        <div
          style={{
            padding: "6px 16px 4px",
            color: colors.textMuted,
            fontSize: 9,
            fontWeight: 700,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
          }}
        >
          ACTIVE TRIAGE ALERTS
        </div>
        {ALERTS.map((a, i) => (
          <div
            key={a.id}
            style={{
              padding: "9px 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              background:
                i === tick % ALERTS.length
                  ? "rgba(6,182,212,0.05)"
                  : "transparent",
              borderLeft:
                i === tick % ALERTS.length
                  ? `2px solid ${colors.cyan}`
                  : "2px solid transparent",
              transition: "all 0.5s ease",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: "50%",
                  background: a.color,
                  boxShadow: `0 0 8px ${a.color}`,
                  flexShrink: 0,
                }}
              />
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span
                    style={{
                      color: colors.textPrimary,
                      fontSize: 11,
                      fontWeight: 600,
                    }}
                  >
                    {a.name}
                  </span>
                  <span style={{ color: colors.textMuted, fontSize: 9 }}>
                    {a.id_num}
                  </span>
                </div>
                <div
                  style={{
                    color: colors.textSecondary,
                    fontSize: 10,
                    marginTop: 1,
                  }}
                >
                  {a.symptom}
                </div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span
                style={{
                  color: a.color,
                  fontSize: 9,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  background: `${a.color}18`,
                  padding: "2px 7px",
                  borderRadius: 5,
                }}
              >
                {a.severity}
              </span>
              <span style={{ color: colors.textMuted, fontSize: 9 }}>
                {a.time}
              </span>
            </div>
          </div>
        ))}
      </div>
      <div
        style={{
          margin: "0 14px 14px",
          padding: "11px 14px",
          background: "rgba(6,182,212,0.06)",
          border: `1px solid rgba(6,182,212,0.2)`,
          borderRadius: 10,
        }}
      >
        <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
          <Brain
            size={14}
            color={colors.cyan}
            style={{ marginTop: 1, flexShrink: 0 }}
          />
          <div>
            <div
              style={{
                color: colors.cyan,
                fontSize: 9,
                fontWeight: 700,
                letterSpacing: "0.08em",
                marginBottom: 3,
              }}
            >
              AI CLINICAL INSIGHT
            </div>
            <div
              style={{
                color: colors.textSecondary,
                fontSize: 10,
                lineHeight: 1.5,
              }}
            >
              Patient Leila Hassan — Stroke risk elevated. Immediate neurology
              referral. Confidence: 94.7%
            </div>
          </div>
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: 1,
          background:
            "linear-gradient(90deg,transparent,rgba(6,182,212,0.7),transparent)",
          animation: "scan 5s linear infinite",
        }}
      />
      <style>{`@keyframes scan{from{top:0}to{top:100%}}`}</style>
    </GlassCard>
  );
}

function Hero() {
  return (
    <section
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        padding: "120px 32px 80px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: "15%",
          left: "5%",
          width: 600,
          height: 600,
          borderRadius: "50%",
          background:
            "radial-gradient(circle,rgba(6,182,212,0.07) 0%,transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "10%",
          right: "5%",
          width: 500,
          height: 500,
          borderRadius: "50%",
          background:
            "radial-gradient(circle,rgba(239,68,68,0.05) 0%,transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          width: "100%",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 80,
          alignItems: "center",
        }}
        className="hero-grid"
      >
        <div style={{ animation: "fadeUp 0.7s ease both" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              marginBottom: 28,
              flexWrap: "wrap",
            }}
          >
            <Badge color="cyan" dot>
              AI-Powered Healthcare SaaS
            </Badge>
            <Badge color="green">HIPAA Compliant</Badge>
            <Badge color="amber">SOC 2 Type II</Badge>
          </div>
          <h1
            style={{
              fontSize: "clamp(38px,5vw,68px)",
              fontWeight: 900,
              color: colors.textPrimary,
              lineHeight: 1.06,
              letterSpacing: "-0.035em",
              margin: 0,
            }}
          >
            Triage That <span style={{ color: colors.cyan }}>Remembers</span>{" "}
            Every Patient.
          </h1>
          <p
            style={{
              fontSize: 18,
              color: colors.textSecondary,
              lineHeight: 1.75,
              margin: "28px 0 44px",
              maxWidth: 520,
            }}
          >
            VitalSync transforms emergency care using lifelong medical
            intelligence, real-time triage, predictive hospital analytics, and
            emergency-first decision systems — built for the hospitals of
            tomorrow.
          </p>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: 12,
              marginBottom: 48,
            }}
          >
            <CyanButton
              variant="solid"
              size="lg"
              onClick={() => (window.location.href = "/vault")}
            >
              <Heart size={18} /> Patient Portal
            </CyanButton>
            <CyanButton
              variant="outline"
              size="lg"
              onClick={() => (window.location.href = "/doctor")}
            >
              <Monitor size={18} /> Command Center
            </CyanButton>
            <CyanButton
              variant="ghost"
              size="lg"
              onClick={() => (window.location.href = "/kiosk")}
            >
              <Radio size={18} /> Hospital Kiosk
            </CyanButton>
            <CyanButton
              variant="ghost"
              size="lg"
              onClick={() => (window.location.href = "/about")}
            >
              <Play size={18} /> Request Demo
            </CyanButton>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 28,
              flexWrap: "wrap",
            }}
          >
            {[
              "SOC 2 Type II",
              "HIPAA Compliant",
              "HL7 FHIR Ready",
              "ISO 27001",
            ].map((b) => (
              <div
                key={b}
                style={{ display: "flex", alignItems: "center", gap: 6 }}
              >
                <Shield size={12} color={colors.green} />
                <span
                  style={{
                    color: colors.textMuted,
                    fontSize: 12,
                    fontWeight: 500,
                  }}
                >
                  {b}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ animation: "fadeUp 0.8s 0.15s ease both" }}>
          <LiveDashboard />
        </div>
      </div>
      <style>{`@media(max-width:960px){.hero-grid{grid-template-columns:1fr!important;gap:48px!important}}`}</style>
    </section>
  );
}

function StatsBar() {
  const stats = [
    { n: "2.4M+", l: "Patient Records" },
    { n: "58%", l: "Faster Triage" },
    { n: "340+", l: "Partner Hospitals" },
    { n: "99.97%", l: "System Uptime" },
    { n: "$12M", l: "Costs Saved" },
    { n: "94.7%", l: "AI Accuracy" },
  ];
  return (
    <section
      style={{
        borderTop: `1px solid ${colors.border}`,
        borderBottom: `1px solid ${colors.border}`,
        padding: "32px",
        background: "rgba(6,182,212,0.02)",
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "repeat(6,1fr)",
          gap: 0,
        }}
        className="stats-grid"
      >
        {stats.map((s, i) => (
          <div
            key={i}
            style={{
              textAlign: "center",
              padding: "8px",
              borderRight: i < 5 ? `1px solid ${colors.border}` : "none",
            }}
          >
            <div
              style={{
                color: colors.cyan,
                fontSize: "clamp(20px,2vw,28px)",
                fontWeight: 900,
                letterSpacing: "-0.02em",
              }}
            >
              {s.n}
            </div>
            <div
              style={{
                color: colors.textMuted,
                fontSize: 12,
                fontWeight: 500,
                marginTop: 4,
              }}
            >
              {s.l}
            </div>
          </div>
        ))}
      </div>
      <style>{`@media(max-width:860px){.stats-grid{grid-template-columns:repeat(3,1fr)!important}}`}</style>
    </section>
  );
}

function PlatformCards() {
  const apps = [
    {
      icon: <Heart size={26} color={colors.cyan} />,
      label: "Patient Vault",
      tag: "Mobile + Web",
      tagColor: "cyan",
      desc: "Lifelong medical timeline, emergency SOS with GPS routing, cloud vault for all records and documents.",
      href: "/vault",
    },
    {
      icon: <Radio size={26} color={colors.amber} />,
      label: "Smart Intake Kiosk",
      tag: "Tablet-First",
      tagColor: "amber",
      desc: "Hospital check-in with National ID, symptom logging, accessibility features, and instant queue entry.",
      href: "/kiosk",
    },
    {
      icon: <Stethoscope size={26} color={colors.green} />,
      label: "Doctor Command Center",
      tag: "Desktop + Web",
      tagColor: "green",
      desc: "Live patient queue, AI clinical summaries from full history, diagnosis interface, cloud finalization.",
      href: "/doctor",
    },
    {
      icon: <Brain size={26} color="#A78BFA" />,
      label: "AI Triage Engine",
      tag: "Embedded AI",
      tagColor: "cyan",
      desc: "Symptom × history analysis, risk stratification, emergency routing, and predictive clinical alerts.",
      href: "/features",
    },
  ];
  return (
    <section style={{ padding: "100px 32px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 64 }}>
          <SectionLabel>The Platform</SectionLabel>
          <h2
            style={{
              color: colors.textPrimary,
              fontSize: "clamp(28px,4vw,50px)",
              fontWeight: 800,
              margin: "16px 0 16px",
              letterSpacing: "-0.025em",
            }}
          >
            One Ecosystem. Every Touchpoint.
          </h2>
          <p
            style={{
              color: colors.textSecondary,
              fontSize: 17,
              maxWidth: 560,
              margin: "0 auto",
            }}
          >
            From patient onboarding to real-time diagnosis — VitalSync connects
            every layer of emergency healthcare.
          </p>
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4,1fr)",
            gap: 20,
          }}
          className="apps-grid"
        >
          {apps.map((a, i) => (
            <GlassCard
              key={i}
              hover
              onClick={() => (window.location.href = a.href)}
              style={{ padding: "28px 22px", cursor: "pointer" }}
            >
              <div
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 13,
                  background: "rgba(6,182,212,0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 16,
                }}
              >
                {a.icon}
              </div>
              <Badge color={a.tagColor}>{a.tag}</Badge>
              <h3
                style={{
                  color: colors.textPrimary,
                  fontSize: 17,
                  fontWeight: 700,
                  margin: "12px 0 8px",
                  letterSpacing: "-0.01em",
                }}
              >
                {a.label}
              </h3>
              <p
                style={{
                  color: colors.textSecondary,
                  fontSize: 13,
                  lineHeight: 1.6,
                  margin: 0,
                }}
              >
                {a.desc}
              </p>
              <div
                style={{
                  marginTop: 20,
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  color: colors.cyan,
                  fontSize: 13,
                  fontWeight: 600,
                }}
              >
                Open <ChevronRight size={14} />
              </div>
            </GlassCard>
          ))}
        </div>
        <style>{`@media(max-width:960px){.apps-grid{grid-template-columns:repeat(2,1fr)!important}}@media(max-width:540px){.apps-grid{grid-template-columns:1fr!important}}`}</style>
      </div>
    </section>
  );
}

function FeatureStrip() {
  const feats = [
    {
      icon: <Zap size={20} />,
      title: "Real-Time Sync",
      desc: "Kiosk check-in instantly reflects in the doctor queue via live database polling.",
    },
    {
      icon: <Brain size={20} />,
      title: "AI Clinical Intelligence",
      desc: "Symptom analysis cross-referenced with complete patient history in milliseconds.",
    },
    {
      icon: <Shield size={20} />,
      title: "HIPAA-Grade Security",
      desc: "Row-level security, encrypted at rest, full audit logs, SOC 2 compliance.",
    },
    {
      icon: <Globe size={20} />,
      title: "National ID Identity",
      desc: "Every patient uniquely identified across all partner hospitals by National ID.",
    },
    {
      icon: <Database size={20} />,
      title: "Cloud Medical Vault",
      desc: "Blood work, X-rays, prescriptions — stored securely, accessible anywhere.",
    },
    {
      icon: <AlertTriangle size={20} />,
      title: "Emergency SOS",
      desc: "One-tap GPS triage with ambulance routing, family alerts, and hospital matching.",
    },
  ];
  return (
    <section
      style={{
        padding: "80px 32px",
        borderTop: `1px solid ${colors.border}`,
        background: "rgba(255,255,255,0.01)",
      }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 56 }}>
          <SectionLabel>Core Intelligence</SectionLabel>
          <h2
            style={{
              color: colors.textPrimary,
              fontSize: "clamp(24px,3vw,42px)",
              fontWeight: 800,
              margin: "16px 0 0",
              letterSpacing: "-0.02em",
            }}
          >
            Built for the Hardest Moments in Medicine
          </h2>
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: 20,
          }}
          className="feats-grid"
        >
          {feats.map((f, i) => (
            <GlassCard key={i} style={{ padding: "24px" }}>
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  background: "rgba(6,182,212,0.1)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: colors.cyan,
                  marginBottom: 16,
                }}
              >
                {f.icon}
              </div>
              <h4
                style={{
                  color: colors.textPrimary,
                  fontSize: 16,
                  fontWeight: 700,
                  margin: "0 0 8px",
                }}
              >
                {f.title}
              </h4>
              <p
                style={{
                  color: colors.textSecondary,
                  fontSize: 13,
                  lineHeight: 1.6,
                  margin: 0,
                }}
              >
                {f.desc}
              </p>
            </GlassCard>
          ))}
        </div>
        <style>{`@media(max-width:860px){.feats-grid{grid-template-columns:repeat(2,1fr)!important}}@media(max-width:540px){.feats-grid{grid-template-columns:1fr!important}}`}</style>
      </div>
    </section>
  );
}

function Testimonial() {
  const quotes = [
    {
      q: "VitalSync cut our ER triage time by 61%. It's the most impactful clinical tool we've deployed in a decade.",
      name: "Dr. Michael Torres",
      role: "Chief Medical Officer, St. Claire Health System",
    },
    {
      q: "The AI clinical summaries alone save each of our doctors 45 minutes per shift. The ROI was visible in week one.",
      name: "Dr. Priya Nair",
      role: "Emergency Medicine Director, NovaCare",
    },
    {
      q: "Finally a platform that understands the chaos of emergency medicine. VitalSync is the infrastructure we've needed.",
      name: "James Whitfield",
      role: "CTO, Meridian Regional Hospital",
    },
  ];
  return (
    <section style={{ padding: "100px 32px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 56 }}>
          <SectionLabel>Trusted by Leaders</SectionLabel>
          <h2
            style={{
              color: colors.textPrimary,
              fontSize: "clamp(24px,3vw,42px)",
              fontWeight: 800,
              margin: "16px 0 0",
              letterSpacing: "-0.02em",
            }}
          >
            What Medical Leaders Are Saying
          </h2>
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: 20,
          }}
          className="quotes-grid"
        >
          {quotes.map((q, i) => (
            <GlassCard key={i} style={{ padding: "28px 24px" }}>
              <div style={{ display: "flex", gap: 2, marginBottom: 16 }}>
                {[...Array(5)].map((_, j) => (
                  <Star
                    key={j}
                    size={14}
                    color={colors.amber}
                    fill={colors.amber}
                  />
                ))}
              </div>
              <p
                style={{
                  color: colors.textSecondary,
                  fontSize: 14,
                  lineHeight: 1.7,
                  margin: "0 0 20px",
                  fontStyle: "italic",
                }}
              >
                "{q.q}"
              </p>
              <div
                style={{
                  borderTop: `1px solid ${colors.border}`,
                  paddingTop: 16,
                }}
              >
                <div
                  style={{
                    color: colors.textPrimary,
                    fontSize: 13,
                    fontWeight: 700,
                  }}
                >
                  {q.name}
                </div>
                <div
                  style={{
                    color: colors.textMuted,
                    fontSize: 12,
                    marginTop: 2,
                  }}
                >
                  {q.role}
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
        <style>{`@media(max-width:860px){.quotes-grid{grid-template-columns:1fr!important}}`}</style>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section style={{ padding: "80px 32px 120px" }}>
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <GlassCard
          style={{
            padding: "72px 64px",
            textAlign: "center",
            border: `1px solid rgba(6,182,212,0.2)`,
            boxShadow: "0 0 100px rgba(6,182,212,0.08)",
          }}
        >
          <Badge color="cyan" dot>
            Investor Grade Platform
          </Badge>
          <h2
            style={{
              color: colors.textPrimary,
              fontSize: "clamp(28px,4vw,54px)",
              fontWeight: 900,
              margin: "24px 0 16px",
              letterSpacing: "-0.03em",
            }}
          >
            The Infrastructure Hospitals Have Been Waiting For
          </h2>
          <p
            style={{
              color: colors.textSecondary,
              fontSize: 17,
              lineHeight: 1.7,
              maxWidth: 560,
              margin: "0 auto 44px",
            }}
          >
            One platform eliminating triage delays, record fragmentation, and
            emergency response gaps. VitalSync is the operating system for
            modern emergency medicine.
          </p>
          <div
            style={{
              display: "flex",
              gap: 16,
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <CyanButton
              variant="solid"
              size="xl"
              onClick={() => (window.location.href = "/register")}
            >
              Get Started Free <ArrowRight size={18} />
            </CyanButton>
            <CyanButton
              variant="outline"
              size="xl"
              onClick={() => (window.location.href = "/why")}
            >
              View ROI Report
            </CyanButton>
          </div>
        </GlassCard>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer
      style={{ borderTop: `1px solid ${colors.border}`, padding: "48px 32px" }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 24,
            marginBottom: 32,
          }}
        >
          <a
            href="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              textDecoration: "none",
            }}
          >
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                background: "linear-gradient(135deg,#06B6D4,#0284C7)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Activity size={16} color="#000" />
            </div>
            <span
              style={{
                color: colors.textPrimary,
                fontWeight: 700,
                fontSize: 16,
              }}
            >
              VitalSync
            </span>
          </a>
          <div style={{ display: "flex", gap: 28, flexWrap: "wrap" }}>
            {[
              ["About", "/about"],
              ["Features", "/features"],
              ["Why Us", "/why"],
              ["Patient Portal", "/vault"],
              ["Doctor Center", "/doctor"],
              ["Kiosk", "/kiosk"],
            ].map(([l, h]) => (
              <a
                key={l}
                href={h}
                style={{
                  color: colors.textMuted,
                  fontSize: 13,
                  textDecoration: "none",
                }}
              >
                {l}
              </a>
            ))}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <GlowDot color={colors.green} size={7} />
            <span style={{ color: colors.textMuted, fontSize: 12 }}>
              All systems operational
            </span>
          </div>
        </div>
        <div
          style={{
            borderTop: `1px solid ${colors.border}`,
            paddingTop: 24,
            display: "flex",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 16,
          }}
        >
          <span style={{ color: colors.textMuted, fontSize: 12 }}>
            © 2026 VitalSync Corp. All rights reserved.
          </span>
          <div style={{ display: "flex", gap: 20 }}>
            {["Privacy", "Security", "HIPAA", "Terms"].map((l) => (
              <a
                key={l}
                href="#"
                style={{
                  color: colors.textMuted,
                  fontSize: 12,
                  textDecoration: "none",
                }}
              >
                {l}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function LandingPage() {
  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
      }}
    >
      <GlobalStyles />
      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}`}</style>
      <Navbar />
      <Hero />
      <StatsBar />
      <PlatformCards />
      <FeatureStrip />
      <Testimonial />
      <FinalCTA />
      <Footer />
    </div>
  );
}
