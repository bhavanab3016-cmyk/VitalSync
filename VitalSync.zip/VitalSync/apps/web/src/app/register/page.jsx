"use client";
import React, { useState } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  GlobalStyles,
  Input,
  Textarea,
  colors,
} from "../../components/VS";
import {
  Activity,
  User,
  Building2,
  ArrowLeft,
  CheckCircle2,
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";

function Navbar() {
  return (
    <nav
      style={{
        padding: "20px 32px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <a
        href="/"
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          textDecoration: "none",
        }}
      >
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 9,
            background: "linear-gradient(135deg,#06B6D4,#0284C7)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Activity size={18} color="#000" />
        </div>
        <span
          style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
        >
          VitalSync
        </span>
      </a>
      <a
        href="/login"
        style={{
          color: colors.cyan,
          fontSize: 14,
          fontWeight: 600,
          textDecoration: "none",
        }}
      >
        Already registered? Sign In →
      </a>
    </nav>
  );
}

const FIELD = ({ label, children }) => (
  <div>
    <label
      style={{
        color: colors.textMuted,
        fontSize: 11,
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        display: "block",
        marginBottom: 8,
      }}
    >
      {label}
    </label>
    {children}
  </div>
);

export default function RegisterPage() {
  const [type, setType] = useState(null);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const [personal, setPersonal] = useState({
    national_id: "",
    full_name: "",
    email: "",
    dob: "",
    gender: "",
  });
  const [enterprise, setEnterprise] = useState({
    hospital_name: "",
    doctor_count: "",
    services: "",
    icu: "",
    emergency_capacity: "",
    insurance: "",
    hours: "",
    emergency_dept: "",
  });

  const personalMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/patients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(personal),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Registration failed");
      return data;
    },
    onSuccess: (data) => {
      if (typeof window !== "undefined")
        localStorage.setItem("vital_patient", JSON.stringify(data));
      setSuccess(true);
    },
    onError: (e) => setError(e.message),
  });

  if (success) {
    return (
      <div
        style={{
          background: colors.bg,
          minHeight: "100vh",
          fontFamily: "'Inter',sans-serif",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <GlobalStyles />
        <Navbar />
        <div
          style={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "40px 32px",
          }}
        >
          <GlassCard
            style={{
              padding: "64px 48px",
              textAlign: "center",
              maxWidth: 520,
              border: `1px solid rgba(16,185,129,0.3)`,
            }}
          >
            <div
              style={{
                width: 72,
                height: 72,
                borderRadius: "50%",
                background: "rgba(16,185,129,0.15)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 24px",
              }}
            >
              <CheckCircle2 size={36} color={colors.green} />
            </div>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: 28,
                fontWeight: 800,
                margin: "0 0 12px",
              }}
            >
              Identity Created
            </h2>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 15,
                lineHeight: 1.7,
                margin: "0 0 32px",
              }}
            >
              Your VitalSync medical identity is now live in the cloud. Your
              records will follow you across every partner hospital.
            </p>
            <CyanButton
              variant="solid"
              size="lg"
              full
              onClick={() => (window.location.href = "/vault")}
            >
              Open Your Patient Vault →
            </CyanButton>
          </GlassCard>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <GlobalStyles />
      <Navbar />

      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "40px 32px",
        }}
      >
        <div style={{ width: "100%", maxWidth: type ? 560 : 760 }}>
          {!type ? (
            <>
              <div style={{ textAlign: "center", marginBottom: 48 }}>
                <Badge color="cyan" dot>
                  Create Account
                </Badge>
                <h1
                  style={{
                    color: colors.textPrimary,
                    fontSize: "clamp(28px,4vw,52px)",
                    fontWeight: 900,
                    margin: "20px 0 12px",
                    letterSpacing: "-0.03em",
                  }}
                >
                  Register on VitalSync
                </h1>
                <p style={{ color: colors.textSecondary, fontSize: 16 }}>
                  Choose your registration type to get started.
                </p>
              </div>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 20,
                }}
                className="reg-type-grid"
              >
                <GlassCard
                  hover
                  onClick={() => setType("personal")}
                  style={{
                    padding: "40px 32px",
                    cursor: "pointer",
                    textAlign: "center",
                  }}
                >
                  <div
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: "50%",
                      background: "rgba(6,182,212,0.12)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 20px",
                    }}
                  >
                    <User size={30} color={colors.cyan} />
                  </div>
                  <div
                    style={{
                      color: colors.textPrimary,
                      fontSize: 20,
                      fontWeight: 800,
                      marginBottom: 8,
                    }}
                  >
                    Personal User
                  </div>
                  <div
                    style={{
                      color: colors.textMuted,
                      fontSize: 14,
                      lineHeight: 1.6,
                      marginBottom: 20,
                    }}
                  >
                    Create your individual lifelong medical identity and access
                    the Patient Vault.
                  </div>
                  <CyanButton variant="outline" size="md">
                    Register as Patient
                  </CyanButton>
                </GlassCard>
                <GlassCard
                  hover
                  onClick={() => setType("enterprise")}
                  style={{
                    padding: "40px 32px",
                    cursor: "pointer",
                    textAlign: "center",
                  }}
                >
                  <div
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: "50%",
                      background: "rgba(167,139,250,0.12)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 20px",
                    }}
                  >
                    <Building2 size={30} color="#A78BFA" />
                  </div>
                  <div
                    style={{
                      color: colors.textPrimary,
                      fontSize: 20,
                      fontWeight: 800,
                      marginBottom: 8,
                    }}
                  >
                    Enterprise User
                  </div>
                  <div
                    style={{
                      color: colors.textMuted,
                      fontSize: 14,
                      lineHeight: 1.6,
                      marginBottom: 20,
                    }}
                  >
                    Onboard your hospital or health network to the VitalSync
                    ecosystem.
                  </div>
                  <CyanButton
                    variant="outline"
                    size="md"
                    style={{
                      borderColor: "rgba(167,139,250,0.5)",
                      color: "#A78BFA",
                    }}
                  >
                    Register Hospital
                  </CyanButton>
                </GlassCard>
              </div>
              <style>{`@media(max-width:600px){.reg-type-grid{grid-template-columns:1fr!important}}`}</style>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  setType(null);
                  setError("");
                }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  color: colors.textMuted,
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontSize: 14,
                  marginBottom: 32,
                }}
              >
                <ArrowLeft size={16} /> Back
              </button>
              <GlassCard
                style={{
                  padding: "40px",
                  border: `1px solid rgba(6,182,212,0.2)`,
                }}
              >
                <h2
                  style={{
                    color: colors.textPrimary,
                    fontSize: 22,
                    fontWeight: 800,
                    margin: "0 0 8px",
                  }}
                >
                  {type === "personal"
                    ? "Create Personal Medical Identity"
                    : "Register Your Hospital"}
                </h2>
                <p
                  style={{
                    color: colors.textMuted,
                    fontSize: 14,
                    margin: "0 0 32px",
                  }}
                >
                  {type === "personal"
                    ? "Your National ID becomes your universal medical identifier across all VitalSync partner hospitals."
                    : "Set up your hospital on the VitalSync network for instant interoperability."}
                </p>

                {error && (
                  <div
                    style={{
                      background: "rgba(239,68,68,0.1)",
                      border: "1px solid rgba(239,68,68,0.3)",
                      borderRadius: 10,
                      padding: "12px 16px",
                      color: colors.red,
                      fontSize: 13,
                      marginBottom: 20,
                    }}
                  >
                    {error}
                  </div>
                )}

                {type === "personal" ? (
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: 18,
                    }}
                  >
                    <FIELD label="National ID">
                      <Input
                        placeholder="e.g. ID-004"
                        value={personal.national_id}
                        onChange={(e) =>
                          setPersonal((p) => ({
                            ...p,
                            national_id: e.target.value,
                          }))
                        }
                      />
                    </FIELD>
                    <FIELD label="Full Name">
                      <Input
                        placeholder="Full legal name"
                        value={personal.full_name}
                        onChange={(e) =>
                          setPersonal((p) => ({
                            ...p,
                            full_name: e.target.value,
                          }))
                        }
                      />
                    </FIELD>
                    <FIELD label="Email Address">
                      <Input
                        type="email"
                        placeholder="your@email.com"
                        value={personal.email}
                        onChange={(e) =>
                          setPersonal((p) => ({ ...p, email: e.target.value }))
                        }
                      />
                    </FIELD>
                    <FIELD label="Date of Birth">
                      <Input
                        type="date"
                        value={personal.dob}
                        onChange={(e) =>
                          setPersonal((p) => ({ ...p, dob: e.target.value }))
                        }
                      />
                    </FIELD>
                    <FIELD label="Gender">
                      <select
                        value={personal.gender}
                        onChange={(e) =>
                          setPersonal((p) => ({ ...p, gender: e.target.value }))
                        }
                        style={{
                          width: "100%",
                          background: "rgba(255,255,255,0.04)",
                          border: `1px solid ${colors.border}`,
                          borderRadius: 12,
                          padding: "13px 16px",
                          color: colors.textPrimary,
                          fontSize: 14,
                          outline: "none",
                        }}
                      >
                        <option value="">Select gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Non-binary">Non-binary</option>
                        <option value="Prefer not to say">
                          Prefer not to say
                        </option>
                      </select>
                    </FIELD>
                    <CyanButton
                      variant="solid"
                      size="lg"
                      full
                      disabled={personalMutation.isPending}
                      onClick={() => {
                        setError("");
                        personalMutation.mutate();
                      }}
                    >
                      {personalMutation.isPending
                        ? "Creating Identity…"
                        : "Create My Medical Identity"}
                    </CyanButton>
                  </div>
                ) : (
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: 18,
                    }}
                  >
                    <FIELD label="Hospital Name">
                      <Input
                        placeholder="e.g. St. Claire Medical Center"
                        value={enterprise.hospital_name}
                        onChange={(e) =>
                          setEnterprise((p) => ({
                            ...p,
                            hospital_name: e.target.value,
                          }))
                        }
                      />
                    </FIELD>
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "1fr 1fr",
                        gap: 16,
                      }}
                    >
                      <FIELD label="Doctor Count">
                        <Input
                          placeholder="e.g. 120"
                          value={enterprise.doctor_count}
                          onChange={(e) =>
                            setEnterprise((p) => ({
                              ...p,
                              doctor_count: e.target.value,
                            }))
                          }
                        />
                      </FIELD>
                      <FIELD label="Emergency Capacity">
                        <Input
                          placeholder="Beds e.g. 48"
                          value={enterprise.emergency_capacity}
                          onChange={(e) =>
                            setEnterprise((p) => ({
                              ...p,
                              emergency_capacity: e.target.value,
                            }))
                          }
                        />
                      </FIELD>
                    </div>
                    <FIELD label="Services Offered">
                      <Input
                        placeholder="Cardiology, Oncology, Neurology…"
                        value={enterprise.services}
                        onChange={(e) =>
                          setEnterprise((p) => ({
                            ...p,
                            services: e.target.value,
                          }))
                        }
                      />
                    </FIELD>
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "1fr 1fr",
                        gap: 16,
                      }}
                    >
                      <FIELD label="ICU Beds Available">
                        <Input
                          placeholder="e.g. 24"
                          value={enterprise.icu}
                          onChange={(e) =>
                            setEnterprise((p) => ({
                              ...p,
                              icu: e.target.value,
                            }))
                          }
                        />
                      </FIELD>
                      <FIELD label="Working Hours">
                        <Input
                          placeholder="e.g. 24/7"
                          value={enterprise.hours}
                          onChange={(e) =>
                            setEnterprise((p) => ({
                              ...p,
                              hours: e.target.value,
                            }))
                          }
                        />
                      </FIELD>
                    </div>
                    <FIELD label="Insurance Providers Accepted">
                      <Input
                        placeholder="BlueCross, Aetna, Medicare…"
                        value={enterprise.insurance}
                        onChange={(e) =>
                          setEnterprise((p) => ({
                            ...p,
                            insurance: e.target.value,
                          }))
                        }
                      />
                    </FIELD>
                    <FIELD label="Emergency Department Support">
                      <select
                        value={enterprise.emergency_dept}
                        onChange={(e) =>
                          setEnterprise((p) => ({
                            ...p,
                            emergency_dept: e.target.value,
                          }))
                        }
                        style={{
                          width: "100%",
                          background: "rgba(255,255,255,0.04)",
                          border: `1px solid ${colors.border}`,
                          borderRadius: 12,
                          padding: "13px 16px",
                          color: colors.textPrimary,
                          fontSize: 14,
                          outline: "none",
                        }}
                      >
                        <option value="">Select level</option>
                        <option value="Level 1 Trauma">
                          Level 1 Trauma Center
                        </option>
                        <option value="Level 2 Trauma">
                          Level 2 Trauma Center
                        </option>
                        <option value="General ER">
                          General Emergency Room
                        </option>
                        <option value="Urgent Care">Urgent Care Only</option>
                      </select>
                    </FIELD>
                    <CyanButton
                      variant="solid"
                      size="lg"
                      full
                      onClick={() =>
                        alert(
                          "Enterprise registration submitted. Our integration team will contact you within 24 hours.",
                        )
                      }
                    >
                      Submit Integration Request
                    </CyanButton>
                  </div>
                )}
              </GlassCard>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
