"use client";
import React, { useState } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  SectionLabel,
  GlowDot,
  GlobalStyles,
  colors,
} from "../../components/VS";
import {
  Activity,
  Brain,
  Heart,
  Radio,
  Monitor,
  Shield,
  Database,
  AlertTriangle,
  BarChart3,
  Cpu,
  Users,
  Clock,
  Zap,
  Lock,
  FileText,
  Stethoscope,
  TrendingUp,
  Globe,
} from "lucide-react";

function Navbar() {
  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        background: "rgba(2,6,23,0.95)",
        backdropFilter: "blur(20px)",
        borderBottom: `1px solid ${colors.border}`,
        padding: "0 32px",
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 64,
        }}
      >
        <a
          href="/"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            textDecoration: "none",
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={18} color="#000" />
          </div>
          <span
            style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
          >
            VitalSync
          </span>
        </a>
        <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
          {[
            ["Home", "/"],
            ["About", "/about"],
            ["Why Us", "/why"],
            ["Login", "/login"],
          ].map(([l, h]) => (
            <a
              key={l}
              href={h}
              style={{
                color: colors.textSecondary,
                fontSize: 14,
                textDecoration: "none",
                fontWeight: 500,
              }}
            >
              {l}
            </a>
          ))}
          <CyanButton
            variant="solid"
            size="sm"
            onClick={() => (window.location.href = "/register")}
          >
            Get Started
          </CyanButton>
        </div>
      </div>
    </nav>
  );
}

const ALL_FEATURES = [
  {
    icon: <Heart size={28} color={colors.cyan} />,
    title: "Patient Vault",
    tag: "Core",
    tagColor: "cyan",
    headline: "Your Lifelong Medical Identity",
    desc: "A single, encrypted, globally-accessible medical profile per patient. Tied to National ID. Complete with timelines, emergency contacts, cloud-stored documents, and AI-powered health scoring.",
    points: [
      "Lifetime medical timeline",
      "Cloud document vault (PDFs, DICOMs)",
      "Emergency QR code for first responders",
      "Family emergency access mode",
      "Health score & alert monitoring",
    ],
    href: "/vault",
  },
  {
    icon: <Radio size={28} color={colors.amber} />,
    title: "Smart Intake Kiosk",
    tag: "Kiosk",
    tagColor: "amber",
    headline: "Frictionless Hospital Check-In",
    desc: "Tablet-first patient identification and symptom intake. Verifies identity via National ID in under 3 seconds, logs symptom selection, and pushes directly to the doctor queue — no paper, no waiting.",
    points: [
      "National ID verification",
      "Symptom selection interface",
      "Accessibility mode (voice, contrast)",
      "Elder-friendly large-button UI",
      "Real-time queue entry",
    ],
    href: "/kiosk",
  },
  {
    icon: <Monitor size={28} color={colors.green} />,
    title: "Doctor Command Center",
    tag: "Clinical",
    tagColor: "green",
    headline: "The Clinical Desktop Reimagined",
    desc: "A real-time operations center for doctors and nurses. Live patient queue, full cloud history, AI-generated clinical summaries, and a diagnosis interface that writes back to the patient's global timeline.",
    points: [
      "Live patient queue (real-time sync)",
      "AI clinical summary per patient",
      "Full cloud history access",
      "Diagnosis + prescription entry",
      "Case closure with cloud sync",
    ],
    href: "/doctor",
  },
  {
    icon: <AlertTriangle size={28} color={colors.red} />,
    title: "Emergency SOS",
    tag: "Emergency",
    tagColor: "red",
    headline: "One Tap. Immediate Response.",
    desc: "Patient-side emergency button that captures GPS, broadcasts identity and medical history to the nearest suitable facility, alerts emergency contacts, and recommends routing based on symptom severity.",
    points: [
      "GPS-based hospital routing",
      "Severity-based facility matching",
      "Family auto-alert system",
      "Medical history broadcast",
      "5-second cancel safety window",
    ],
    href: "/vault",
  },
  {
    icon: <Brain size={28} color="#A78BFA" />,
    title: "AI Triage Engine",
    tag: "AI",
    tagColor: "cyan",
    headline: "Clinical Intelligence at Triage Speed",
    desc: "Symptom data cross-referenced against the patient's complete medical history using our proprietary AI model. Generates risk scores, clinical flags, and specialist routing recommendations in under 200ms.",
    points: [
      "Symptom × history correlation",
      "Risk stratification scoring",
      "Specialist routing logic",
      "Emergency escalation triggers",
      "99.1% clinical accuracy",
    ],
    href: "/",
  },
  {
    icon: <Database size={28} color={colors.cyan} />,
    title: "Cloud Medical Vault",
    tag: "Storage",
    tagColor: "cyan",
    headline: "Every Record. One Place. Always.",
    desc: "Secure cloud storage for all patient documents — blood work PDFs, DICOM imaging, prescriptions, discharge summaries, and insurance records. Accessible from any authorized system, globally.",
    points: [
      "Multi-format file support",
      "DICOM imaging viewer",
      "Prescription archive",
      "Discharge summary storage",
      "Insurance document vault",
    ],
    href: "/vault",
  },
  {
    icon: <Shield size={28} color={colors.green} />,
    title: "Insurance Integration",
    tag: "Finance",
    tagColor: "green",
    headline: "Claims Without the Chaos",
    desc: "Bidirectional insurance integration layer. Automatically populates claim forms from clinical records, tracks authorization status, and generates audit-grade documentation bundles — all from one interface.",
    points: [
      "Auto-populated claim forms",
      "Authorization tracking",
      "Audit documentation bundle",
      "Multi-payer support",
      "HL7 FHIR compliance",
    ],
    href: "/",
  },
  {
    icon: <BarChart3 size={28} color={colors.amber} />,
    title: "Predictive Analytics",
    tag: "Analytics",
    tagColor: "amber",
    headline: "Know What's Coming Before It Arrives",
    desc: "Hospital-wide demand forecasting, ICU bed utilization predictions, and seasonal outbreak pattern recognition. Built on anonymized aggregate data with real-time dashboard visualization.",
    points: [
      "ICU capacity forecasting",
      "Staffing demand prediction",
      "Outbreak pattern detection",
      "Readmission risk scoring",
      "Operational efficiency reports",
    ],
    href: "/why",
  },
  {
    icon: <Cpu size={28} color={colors.cyan} />,
    title: "ICU & Resource Monitor",
    tag: "Operations",
    tagColor: "cyan",
    headline: "Live Hospital Command Intelligence",
    desc: "Real-time visibility into ICU bed availability, ventilator status, nursing ratios, and OR schedule. Integrate with facility management systems to eliminate capacity surprises.",
    points: [
      "Live ICU bed count",
      "Ventilator availability",
      "Nursing shift coverage",
      "OR schedule integration",
      "Equipment maintenance alerts",
    ],
    href: "/doctor",
  },
  {
    icon: <Lock size={28} color={colors.green} />,
    title: "HIPAA Security Layer",
    tag: "Compliance",
    tagColor: "green",
    headline: "Compliance Built Into the Architecture",
    desc: "Not an afterthought — HIPAA, SOC 2, and ISO 27001 principles are baked into every data flow. Row-level security, full audit trails, encryption at rest and in transit, and automated compliance reporting.",
    points: [
      "Row-level database security",
      "Encrypted at rest + transit",
      "Full audit trail logging",
      "Automated compliance reports",
      "BAA-ready infrastructure",
    ],
    href: "/why",
  },
];

export default function FeaturesPage() {
  const [active, setActive] = useState(null);
  const selected = active !== null ? ALL_FEATURES[active] : null;

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
      }}
    >
      <GlobalStyles />
      <Navbar />

      <section style={{ padding: "140px 32px 80px", textAlign: "center" }}>
        <div
          style={{
            position: "absolute",
            top: "10%",
            left: "50%",
            transform: "translateX(-50%)",
            width: 700,
            height: 400,
            borderRadius: "50%",
            background:
              "radial-gradient(circle,rgba(6,182,212,0.06) 0%,transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <Badge color="cyan" dot>
          Platform Features
        </Badge>
        <h1
          style={{
            color: colors.textPrimary,
            fontSize: "clamp(36px,5vw,68px)",
            fontWeight: 900,
            margin: "24px auto 20px",
            letterSpacing: "-0.035em",
            maxWidth: 800,
          }}
        >
          Every Feature Built for{" "}
          <span style={{ color: colors.cyan }}>Clinical Reality</span>
        </h1>
        <p
          style={{
            color: colors.textSecondary,
            fontSize: 18,
            maxWidth: 580,
            margin: "0 auto",
          }}
        >
          Ten interconnected systems. One unified platform. Built to handle the
          complexity of modern emergency medicine.
        </p>
      </section>

      <section style={{ padding: "0 32px 120px" }}>
        <div
          style={{
            maxWidth: 1280,
            margin: "0 auto",
            display: "grid",
            gridTemplateColumns: "1fr 400px",
            gap: 32,
            alignItems: "flex-start",
          }}
          className="feat-layout"
        >
          {/* Feature Grid */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2,1fr)",
              gap: 16,
            }}
            className="feat-grid"
          >
            {ALL_FEATURES.map((f, i) => (
              <GlassCard
                key={i}
                hover
                onClick={() => setActive(active === i ? null : i)}
                style={{
                  padding: "22px",
                  cursor: "pointer",
                  border:
                    active === i
                      ? `1px solid ${colors.cyan}`
                      : `1px solid ${colors.border}`,
                  boxShadow:
                    active === i ? `0 0 30px rgba(6,182,212,0.15)` : "none",
                  transition: "all 0.3s ease",
                }}
              >
                <div
                  style={{ display: "flex", alignItems: "flex-start", gap: 14 }}
                >
                  <div
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 11,
                      background: "rgba(6,182,212,0.08)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {f.icon}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 8,
                        marginBottom: 6,
                        flexWrap: "wrap",
                      }}
                    >
                      <span
                        style={{
                          color: colors.textPrimary,
                          fontSize: 14,
                          fontWeight: 700,
                        }}
                      >
                        {f.title}
                      </span>
                      <Badge color={f.tagColor}>{f.tag}</Badge>
                    </div>
                    <p
                      style={{
                        color: colors.textMuted,
                        fontSize: 12,
                        lineHeight: 1.5,
                        margin: 0,
                      }}
                    >
                      {f.headline}
                    </p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:860px){.feat-grid{grid-template-columns:1fr!important}}`}</style>

          {/* Detail Panel */}
          <div style={{ position: "sticky", top: 90 }}>
            {selected ? (
              <GlassCard
                style={{
                  padding: "32px",
                  border: `1px solid rgba(6,182,212,0.2)`,
                  boxShadow: "0 0 50px rgba(6,182,212,0.08)",
                }}
              >
                <div
                  style={{
                    width: 56,
                    height: 56,
                    borderRadius: 14,
                    background: "rgba(6,182,212,0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 16,
                  }}
                >
                  {selected.icon}
                </div>
                <Badge color={selected.tagColor}>{selected.tag}</Badge>
                <h3
                  style={{
                    color: colors.textPrimary,
                    fontSize: 22,
                    fontWeight: 800,
                    margin: "14px 0 8px",
                    letterSpacing: "-0.02em",
                  }}
                >
                  {selected.title}
                </h3>
                <p
                  style={{
                    color: colors.cyan,
                    fontSize: 13,
                    fontWeight: 600,
                    margin: "0 0 16px",
                  }}
                >
                  {selected.headline}
                </p>
                <p
                  style={{
                    color: colors.textSecondary,
                    fontSize: 14,
                    lineHeight: 1.7,
                    margin: "0 0 24px",
                  }}
                >
                  {selected.desc}
                </p>
                <div
                  style={{
                    borderTop: `1px solid ${colors.border}`,
                    paddingTop: 20,
                    marginBottom: 24,
                  }}
                >
                  <div
                    style={{
                      color: colors.textMuted,
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: "0.08em",
                      textTransform: "uppercase",
                      marginBottom: 12,
                    }}
                  >
                    Key Capabilities
                  </div>
                  {selected.points.map((p, i) => (
                    <div
                      key={i}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        marginBottom: 10,
                      }}
                    >
                      <div
                        style={{
                          width: 18,
                          height: 18,
                          borderRadius: "50%",
                          background: "rgba(6,182,212,0.15)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        <div
                          style={{
                            width: 6,
                            height: 6,
                            borderRadius: "50%",
                            background: colors.cyan,
                          }}
                        />
                      </div>
                      <span
                        style={{ color: colors.textSecondary, fontSize: 13 }}
                      >
                        {p}
                      </span>
                    </div>
                  ))}
                </div>
                <CyanButton
                  variant="solid"
                  full
                  size="md"
                  onClick={() => (window.location.href = selected.href)}
                >
                  Open Feature →
                </CyanButton>
              </GlassCard>
            ) : (
              <GlassCard style={{ padding: "40px", textAlign: "center" }}>
                <div
                  style={{
                    width: 60,
                    height: 60,
                    borderRadius: "50%",
                    background: "rgba(6,182,212,0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 20px",
                  }}
                >
                  <Zap size={28} color={colors.cyan} />
                </div>
                <p
                  style={{
                    color: colors.textSecondary,
                    fontSize: 14,
                    lineHeight: 1.6,
                  }}
                >
                  Select a feature card to explore its capabilities in detail.
                </p>
              </GlassCard>
            )}
          </div>
          <style>{`@media(max-width:1100px){.feat-layout{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>
    </div>
  );
}
