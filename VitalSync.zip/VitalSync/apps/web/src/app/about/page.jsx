"use client";
import React from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  SectionLabel,
  GlowDot,
  GlobalStyles,
  colors,
  Divider,
} from "../../components/VS";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Brain,
  CheckCircle2,
  Clock,
  Database,
  Heart,
  Shield,
  Users,
  Zap,
} from "lucide-react";

function Navbar() {
  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        background: "rgba(2,6,23,0.95)",
        backdropFilter: "blur(20px)",
        borderBottom: `1px solid ${colors.border}`,
        padding: "0 32px",
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 64,
        }}
      >
        <a
          href="/"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            textDecoration: "none",
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={18} color="#000" />
          </div>
          <span
            style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
          >
            VitalSync
          </span>
        </a>
        <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
          {[
            ["Home", "/"],
            ["Features", "/features"],
            ["Why Us", "/why"],
            ["Login", "/login"],
          ].map(([l, h]) => (
            <a
              key={l}
              href={h}
              style={{
                color: colors.textSecondary,
                fontSize: 14,
                textDecoration: "none",
                fontWeight: 500,
              }}
            >
              {l}
            </a>
          ))}
          <CyanButton
            variant="solid"
            size="sm"
            onClick={() => (window.location.href = "/register")}
          >
            Get Started
          </CyanButton>
        </div>
      </div>
    </nav>
  );
}

export default function AboutPage() {
  const problems = [
    {
      icon: <Database size={20} color={colors.red} />,
      title: "Hospitals Forget Patients",
      desc: "Every visit starts from zero. Medical context, allergies, chronic conditions — invisible to the treating team.",
    },
    {
      icon: <AlertTriangle size={20} color={colors.red} />,
      title: "Decisions Without History",
      desc: "Doctors make life-or-death calls with incomplete information. A missing allergy note can be catastrophic.",
    },
    {
      icon: <Clock size={20} color={colors.red} />,
      title: "Emergency Rooms Lose Time",
      desc: "The average ER patient spends 22 minutes re-explaining their history. In cardiac events, that kills people.",
    },
    {
      icon: <Users size={20} color={colors.red} />,
      title: "Records Stay Fragmented",
      desc: "Lab results in one system. Prescriptions in another. Imaging on a CD from 2019. No one has the full picture.",
    },
  ];

  const solutions = [
    {
      icon: <Brain size={20} color={colors.cyan} />,
      title: "Patient Vault",
      desc: "One lifelong, encrypted medical identity per patient — accessible from any authorized hospital, anywhere in the world.",
    },
    {
      icon: <Zap size={20} color={colors.cyan} />,
      title: "Smart Intake Kiosk",
      desc: "Hospital check-in that verifies identity in seconds and instantly populates the doctor's queue with context.",
    },
    {
      icon: <Heart size={20} color={colors.cyan} />,
      title: "Doctor Command Center",
      desc: "Real-time patient queue + complete cloud history + AI clinical decision support — in one desktop interface.",
    },
    {
      icon: <AlertTriangle size={20} color={colors.cyan} />,
      title: "Emergency SOS",
      desc: "GPS-based emergency triage that alerts the right facility with the right patient history before the ambulance arrives.",
    },
    {
      icon: <Database size={20} color={colors.cyan} />,
      title: "AI Triage Engine",
      desc: "Symptom analysis crossed against lifetime history to generate risk scores and clinical recommendations in milliseconds.",
    },
    {
      icon: <Shield size={20} color={colors.cyan} />,
      title: "HIPAA Security Layer",
      desc: "Row-level security, audit trails, end-to-end encryption — compliance baked into the architecture, not bolted on.",
    },
  ];

  const team = [
    {
      name: "Dr. Arjun Mehta",
      role: "CEO & Co-Founder",
      bg: "M",
      color: "#06B6D4",
      note: "Former Chief of Emergency Medicine, Johns Hopkins. 14 years clinical practice.",
    },
    {
      name: "Layla Torres",
      role: "CTO & Co-Founder",
      bg: "L",
      color: "#A78BFA",
      note: "Ex-Stripe Infrastructure. Built real-time payment systems at scale. MIT CS.",
    },
    {
      name: "Dr. Mia Hoffman",
      role: "Chief Medical Officer",
      bg: "H",
      color: "#10B981",
      note: "Stanford Medicine. Led AI clinical decision research for 7 years.",
    },
    {
      name: "Kai Nakamura",
      role: "Chief of Design",
      bg: "K",
      color: "#F59E0B",
      note: "Ex-Apple Health. Designed for 200M+ users. Design systems expert.",
    },
  ];

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
      }}
    >
      <GlobalStyles />
      <Navbar />

      {/* Hero */}
      <section
        style={{
          padding: "140px 32px 80px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "20%",
            left: "50%",
            transform: "translateX(-50%)",
            width: 800,
            height: 400,
            borderRadius: "50%",
            background:
              "radial-gradient(circle,rgba(6,182,212,0.07) 0%,transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <div style={{ maxWidth: 800, margin: "0 auto", position: "relative" }}>
          <Badge color="cyan" dot>
            Our Mission
          </Badge>
          <h1
            style={{
              color: colors.textPrimary,
              fontSize: "clamp(36px,5vw,72px)",
              fontWeight: 900,
              margin: "24px 0 20px",
              letterSpacing: "-0.035em",
              lineHeight: 1.05,
            }}
          >
            Healthcare Should{" "}
            <span style={{ color: colors.cyan }}>Remember.</span>
          </h1>
          <p
            style={{
              color: colors.textSecondary,
              fontSize: 19,
              lineHeight: 1.75,
              maxWidth: 620,
              margin: "0 auto 40px",
            }}
          >
            We built VitalSync because we watched brilliant doctors make
            preventable errors — not from negligence, but from missing context.
            The system failed them. We're fixing the system.
          </p>
          <div
            style={{
              display: "flex",
              gap: 16,
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <CyanButton
              variant="solid"
              size="lg"
              onClick={() => (window.location.href = "/register")}
            >
              Start Free Trial <ArrowRight size={18} />
            </CyanButton>
            <CyanButton
              variant="outline"
              size="lg"
              onClick={() => (window.location.href = "/why")}
            >
              View Clinical ROI
            </CyanButton>
          </div>
        </div>
      </section>

      {/* Problem */}
      <section style={{ padding: "80px 32px" }}>
        <div style={{ maxWidth: 1160, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <SectionLabel>The Problem We Solve</SectionLabel>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(26px,3vw,44px)",
                fontWeight: 800,
                margin: "16px 0 12px",
                letterSpacing: "-0.025em",
              }}
            >
              That Delay Costs Lives.
            </h2>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 16,
                maxWidth: 500,
                margin: "0 auto",
              }}
            >
              Every year, fragmented medical records contribute to over 250,000
              preventable deaths in the US alone.
            </p>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2,1fr)",
              gap: 20,
            }}
            className="prob-grid"
          >
            {problems.map((p, i) => (
              <GlassCard
                key={i}
                style={{
                  padding: "28px 24px",
                  border: `1px solid rgba(239,68,68,0.15)`,
                }}
              >
                <div
                  style={{ display: "flex", gap: 16, alignItems: "flex-start" }}
                >
                  <div
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 11,
                      background: "rgba(239,68,68,0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {p.icon}
                  </div>
                  <div>
                    <h3
                      style={{
                        color: colors.textPrimary,
                        fontSize: 16,
                        fontWeight: 700,
                        margin: "0 0 8px",
                      }}
                    >
                      {p.title}
                    </h3>
                    <p
                      style={{
                        color: colors.textSecondary,
                        fontSize: 14,
                        lineHeight: 1.6,
                        margin: 0,
                      }}
                    >
                      {p.desc}
                    </p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:700px){.prob-grid{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>

      {/* Solution */}
      <section
        style={{
          padding: "80px 32px",
          borderTop: `1px solid ${colors.border}`,
        }}
      >
        <div style={{ maxWidth: 1160, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <SectionLabel>Our Solution</SectionLabel>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(26px,3vw,44px)",
                fontWeight: 800,
                margin: "16px 0 12px",
                letterSpacing: "-0.025em",
              }}
            >
              VitalSync Creates Lifelong
              <br />
              <span style={{ color: colors.cyan }}>Medical Intelligence.</span>
            </h2>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 16,
                maxWidth: 580,
                margin: "0 auto",
              }}
            >
              Every symptom automatically checked against every prior medical
              history. Instantly. Safely. Accurately.
            </p>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3,1fr)",
              gap: 20,
            }}
            className="sol-grid"
          >
            {solutions.map((s, i) => (
              <GlassCard key={i} hover style={{ padding: "26px 22px" }}>
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 11,
                    background: "rgba(6,182,212,0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 16,
                  }}
                >
                  {s.icon}
                </div>
                <h3
                  style={{
                    color: colors.textPrimary,
                    fontSize: 16,
                    fontWeight: 700,
                    margin: "0 0 8px",
                  }}
                >
                  {s.title}
                </h3>
                <p
                  style={{
                    color: colors.textSecondary,
                    fontSize: 13,
                    lineHeight: 1.6,
                    margin: 0,
                  }}
                >
                  {s.desc}
                </p>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:860px){.sol-grid{grid-template-columns:repeat(2,1fr)!important}}@media(max-width:540px){.sol-grid{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>

      {/* Team */}
      <section
        style={{
          padding: "80px 32px",
          borderTop: `1px solid ${colors.border}`,
        }}
      >
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <SectionLabel>The Team</SectionLabel>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(26px,3vw,44px)",
                fontWeight: 800,
                margin: "16px 0 0",
                letterSpacing: "-0.025em",
              }}
            >
              Built by Doctors + Engineers
            </h2>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: 20,
            }}
            className="team-grid"
          >
            {team.map((t, i) => (
              <GlassCard
                key={i}
                style={{ padding: "28px 20px", textAlign: "center" }}
              >
                <div
                  style={{
                    width: 64,
                    height: 64,
                    borderRadius: "50%",
                    background: `${t.color}20`,
                    border: `2px solid ${t.color}40`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 16px",
                    color: t.color,
                    fontSize: 24,
                    fontWeight: 800,
                  }}
                >
                  {t.bg}
                </div>
                <div
                  style={{
                    color: colors.textPrimary,
                    fontSize: 14,
                    fontWeight: 700,
                  }}
                >
                  {t.name}
                </div>
                <div
                  style={{
                    color: colors.cyan,
                    fontSize: 11,
                    fontWeight: 600,
                    margin: "4px 0 10px",
                  }}
                >
                  {t.role}
                </div>
                <p
                  style={{
                    color: colors.textMuted,
                    fontSize: 12,
                    lineHeight: 1.5,
                    margin: 0,
                  }}
                >
                  {t.note}
                </p>
              </GlassCard>
            ))}
          </div>
          <style>{`@media(max-width:860px){.team-grid{grid-template-columns:repeat(2,1fr)!important}}@media(max-width:500px){.team-grid{grid-template-columns:1fr!important}}`}</style>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "80px 32px 120px" }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <GlassCard
            style={{
              padding: "64px",
              textAlign: "center",
              border: `1px solid rgba(6,182,212,0.2)`,
            }}
          >
            <Badge color="cyan" dot>
              Join the Movement
            </Badge>
            <h2
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(24px,3vw,44px)",
                fontWeight: 900,
                margin: "20px 0 16px",
                letterSpacing: "-0.025em",
              }}
            >
              Be Part of the Solution
            </h2>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 16,
                lineHeight: 1.7,
                margin: "0 0 36px",
              }}
            >
              Whether you're a patient, a clinician, or a hospital executive —
              VitalSync exists to serve you.
            </p>
            <div
              style={{
                display: "flex",
                gap: 16,
                justifyContent: "center",
                flexWrap: "wrap",
              }}
            >
              <CyanButton
                variant="solid"
                size="lg"
                onClick={() => (window.location.href = "/register")}
              >
                Register Now
              </CyanButton>
              <CyanButton
                variant="outline"
                size="lg"
                onClick={() => (window.location.href = "/features")}
              >
                See All Features
              </CyanButton>
            </div>
          </GlassCard>
        </div>
      </section>
    </div>
  );
}
