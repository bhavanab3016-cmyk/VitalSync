"use client";
import React, { useState, useRef } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  GlobalStyles,
  GlowDot,
  Input,
  colors,
} from "../../components/VS";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Mic,
  Search,
  User,
  Volume2,
  Zap,
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";

const SYMPTOMS = [
  { label: "Chest Pain", emoji: "💔", severity: "critical" },
  { label: "Shortness of Breath", emoji: "🫁", severity: "critical" },
  { label: "Stroke Symptoms", emoji: "🧠", severity: "critical" },
  { label: "Severe Bleeding", emoji: "🩸", severity: "critical" },
  { label: "Trauma / Injury", emoji: "🦴", severity: "high" },
  { label: "High Fever", emoji: "🌡️", severity: "high" },
  { label: "Seizures", emoji: "⚡", severity: "high" },
  { label: "Severe Headache", emoji: "🤕", severity: "high" },
  { label: "Dizziness", emoji: "💫", severity: "moderate" },
  { label: "Vomiting", emoji: "🤢", severity: "moderate" },
  { label: "Breathing Issues", emoji: "😮‍💨", severity: "moderate" },
  { label: "Pregnancy Emergency", emoji: "🤱", severity: "moderate" },
];

const SEVERITY_COLORS = {
  critical: {
    bg: "rgba(239,68,68,0.12)",
    border: "rgba(239,68,68,0.4)",
    text: colors.red,
  },
  high: {
    bg: "rgba(245,158,11,0.12)",
    border: "rgba(245,158,11,0.35)",
    text: colors.amber,
  },
  moderate: {
    bg: "rgba(6,182,212,0.12)",
    border: "rgba(6,182,212,0.35)",
    text: colors.cyan,
  },
};

export default function KioskPage() {
  const [step, setStep] = useState("identify"); // identify | confirm | symptoms | success
  const [nationalId, setNationalId] = useState("");
  const [patient, setPatient] = useState(null);
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [highContrast, setHighContrast] = useState(false);
  const inputRef = useRef(null);

  const identifyMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/patients?id=${nationalId.trim()}`);
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
    onSuccess: (data) => {
      setPatient(data);
      setStep("confirm");
      setError("");
    },
    onError: () =>
      setError("National ID not found. Please register at the reception desk."),
  });

  const submitMutation = useMutation({
    mutationFn: async () => {
      const symptomsStr = [...selectedSymptoms, notes]
        .filter(Boolean)
        .join(", ");
      const res = await fetch("/api/visits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patient_id: patient.national_id,
          symptoms: symptomsStr,
        }),
      });
      if (!res.ok) throw new Error("Submission failed");
      return res.json();
    },
    onSuccess: () => setStep("success"),
    onError: () =>
      setError("Submission failed. Please try again or see reception."),
  });

  const toggleSymptom = (label) => {
    setSelectedSymptoms((prev) =>
      prev.includes(label) ? prev.filter((s) => s !== label) : [...prev, label],
    );
  };

  const bg = highContrast ? "#000" : colors.bg;
  const cardBg = highContrast ? "rgba(255,255,255,0.08)" : colors.bgCard;

  const reset = () => {
    setStep("identify");
    setNationalId("");
    setPatient(null);
    setSelectedSymptoms([]);
    setNotes("");
    setError("");
  };

  return (
    <div
      style={{
        background: bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <GlobalStyles />

      {/* Top Bar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "20px 40px",
          borderBottom: `1px solid ${colors.border}`,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: 10,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={22} color="#000" />
          </div>
          <div>
            <div
              style={{
                color: colors.textPrimary,
                fontWeight: 800,
                fontSize: 18,
                letterSpacing: "-0.01em",
              }}
            >
              VitalSync Kiosk
            </div>
            <div style={{ color: colors.textMuted, fontSize: 12 }}>
              Smart Patient Intake System
            </div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <GlowDot color={colors.green} />
            <span
              style={{ color: colors.textMuted, fontSize: 12, fontWeight: 600 }}
            >
              CONNECTED
            </span>
          </div>
          <button
            onClick={() => setHighContrast(!highContrast)}
            style={{
              background: highContrast
                ? colors.amber
                : "rgba(255,255,255,0.06)",
              border: `1px solid ${colors.border}`,
              borderRadius: 8,
              padding: "8px 14px",
              color: highContrast ? "#000" : colors.textSecondary,
              fontSize: 12,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            {highContrast ? "Standard Mode" : "High Contrast"}
          </button>
          <button
            style={{
              background: "rgba(6,182,212,0.1)",
              border: `1px solid rgba(6,182,212,0.3)`,
              borderRadius: 8,
              padding: "8px 14px",
              color: colors.cyan,
              fontSize: 12,
              fontWeight: 600,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Volume2 size={14} /> Voice Guide
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div style={{ display: "flex", padding: "16px 40px", gap: 8 }}>
        {[
          ["identify", "1. Identify"],
          ["confirm", "2. Verify"],
          ["symptoms", "3. Symptoms"],
          ["success", "4. Complete"],
        ].map(([s, label], i) => {
          const steps = ["identify", "confirm", "symptoms", "success"];
          const current = steps.indexOf(step);
          const thisIdx = steps.indexOf(s);
          const done = thisIdx < current;
          const active = s === step;
          return (
            <div
              key={s}
              style={{ display: "flex", alignItems: "center", gap: 8, flex: 1 }}
            >
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  flexDirection: "column",
                  gap: 4,
                }}
              >
                <div
                  style={{
                    height: 3,
                    borderRadius: 2,
                    background: done || active ? colors.cyan : colors.border,
                    transition: "all 0.4s ease",
                  }}
                />
                <span
                  style={{
                    color: active
                      ? colors.cyan
                      : done
                        ? colors.green
                        : colors.textMuted,
                    fontSize: 11,
                    fontWeight: 600,
                  }}
                >
                  {label}
                </span>
              </div>
              {i < 3 && <ChevronRight size={14} color={colors.textMuted} />}
            </div>
          );
        })}
      </div>

      {/* Main Content */}
      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "32px 40px",
        }}
      >
        {/* STEP 1: Identify */}
        {step === "identify" && (
          <div style={{ width: "100%", maxWidth: 640, textAlign: "center" }}>
            <div
              style={{
                width: 80,
                height: 80,
                borderRadius: "50%",
                background: "rgba(6,182,212,0.12)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 28px",
              }}
            >
              <User size={38} color={colors.cyan} />
            </div>
            <h1
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(32px,5vw,56px)",
                fontWeight: 900,
                margin: "0 0 12px",
                letterSpacing: "-0.03em",
              }}
            >
              Patient Check-In
            </h1>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 18,
                margin: "0 0 48px",
                lineHeight: 1.6,
              }}
            >
              Enter your National ID to access the intake system and join the
              queue.
            </p>

            {error && (
              <div
                style={{
                  background: "rgba(239,68,68,0.1)",
                  border: "1px solid rgba(239,68,68,0.3)",
                  borderRadius: 12,
                  padding: "14px 20px",
                  color: colors.red,
                  fontSize: 14,
                  marginBottom: 24,
                  textAlign: "left",
                }}
              >
                {error}
              </div>
            )}

            <div style={{ position: "relative", marginBottom: 24 }}>
              <Search
                size={26}
                color={colors.textMuted}
                style={{
                  position: "absolute",
                  left: 24,
                  top: "50%",
                  transform: "translateY(-50%)",
                  pointerEvents: "none",
                }}
              />
              <input
                ref={inputRef}
                type="text"
                placeholder="Enter National ID…"
                value={nationalId}
                onChange={(e) => setNationalId(e.target.value)}
                onKeyDown={(e) =>
                  e.key === "Enter" && identifyMutation.mutate()
                }
                style={{
                  width: "100%",
                  background: "rgba(255,255,255,0.05)",
                  border: `2px solid ${nationalId ? colors.cyan : colors.border}`,
                  borderRadius: 18,
                  padding: "22px 24px 22px 68px",
                  color: colors.textPrimary,
                  fontSize: "clamp(22px,3vw,34px)",
                  fontWeight: 700,
                  outline: "none",
                  textAlign: "center",
                  letterSpacing: "0.06em",
                  transition: "all 0.3s",
                  boxSizing: "border-box",
                  fontFamily: "monospace",
                }}
              />
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 16,
                marginBottom: 32,
              }}
            >
              <CyanButton
                variant="solid"
                size="xl"
                full
                disabled={identifyMutation.isPending}
                onClick={() => {
                  setError("");
                  identifyMutation.mutate();
                }}
              >
                {identifyMutation.isPending ? (
                  "Identifying…"
                ) : (
                  <>
                    <User size={20} /> Identify Me
                  </>
                )}
              </CyanButton>
              <button
                style={{
                  padding: "20px",
                  background: "rgba(255,255,255,0.05)",
                  border: `1px solid ${colors.border}`,
                  borderRadius: 16,
                  color: colors.textSecondary,
                  fontSize: 16,
                  fontWeight: 600,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 10,
                }}
              >
                <Mic size={22} color={colors.cyan} /> Voice Input
              </button>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(3,1fr)",
                gap: 12,
              }}
            >
              {["ID-001", "ID-002", "ID-003"].map((id) => (
                <button
                  key={id}
                  onClick={() => setNationalId(id)}
                  style={{
                    padding: "12px",
                    background: "rgba(6,182,212,0.06)",
                    border: `1px solid rgba(6,182,212,0.2)`,
                    borderRadius: 12,
                    color: colors.cyan,
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: "pointer",
                    fontFamily: "monospace",
                  }}
                >
                  {id}
                </button>
              ))}
            </div>
            <p style={{ color: colors.textMuted, fontSize: 11, marginTop: 10 }}>
              Demo patient IDs
            </p>
          </div>
        )}

        {/* STEP 2: Confirm Identity */}
        {step === "confirm" && patient && (
          <div style={{ width: "100%", maxWidth: 600 }}>
            <GlassCard
              style={{
                padding: "48px",
                border: `1px solid rgba(6,182,212,0.25)`,
                textAlign: "center",
              }}
            >
              <div
                style={{
                  width: 80,
                  height: 80,
                  borderRadius: "50%",
                  background: "rgba(6,182,212,0.12)",
                  border: `2px solid rgba(6,182,212,0.3)`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  margin: "0 auto 24px",
                }}
              >
                <User size={38} color={colors.cyan} />
              </div>
              <Badge color="cyan" dot>
                Identity Located
              </Badge>
              <h2
                style={{
                  color: colors.textPrimary,
                  fontSize: "clamp(24px,4vw,40px)",
                  fontWeight: 900,
                  margin: "16px 0 8px",
                  letterSpacing: "-0.025em",
                }}
              >
                {patient.full_name}
              </h2>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr 1fr",
                  gap: 16,
                  margin: "28px 0 36px",
                }}
              >
                {[
                  { label: "National ID", value: patient.national_id },
                  {
                    label: "Date of Birth",
                    value: new Date(patient.dob).toLocaleDateString(),
                  },
                  { label: "Gender", value: patient.gender || "—" },
                ].map((f, i) => (
                  <div
                    key={i}
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      borderRadius: 12,
                      padding: "14px",
                    }}
                  >
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 10,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        marginBottom: 6,
                      }}
                    >
                      {f.label}
                    </div>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 15,
                        fontWeight: 700,
                      }}
                    >
                      {f.value}
                    </div>
                  </div>
                ))}
              </div>
              <p
                style={{
                  color: colors.textSecondary,
                  fontSize: 15,
                  margin: "0 0 28px",
                }}
              >
                Is this your identity?
              </p>
              <div style={{ display: "flex", gap: 14 }}>
                <button
                  onClick={() => {
                    setStep("identify");
                    setPatient(null);
                    setNationalId("");
                  }}
                  style={{
                    flex: 1,
                    padding: "18px",
                    background: "transparent",
                    border: `1px solid ${colors.border}`,
                    borderRadius: 14,
                    color: colors.textSecondary,
                    fontSize: 15,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  Not Me
                </button>
                <button
                  onClick={() => setStep("symptoms")}
                  style={{
                    flex: 2,
                    padding: "18px",
                    background: colors.cyan,
                    border: "none",
                    borderRadius: 14,
                    color: "#000",
                    fontSize: 16,
                    fontWeight: 800,
                    cursor: "pointer",
                    boxShadow: "0 0 30px rgba(6,182,212,0.35)",
                  }}
                >
                  Yes, That's Me →
                </button>
              </div>
            </GlassCard>
          </div>
        )}

        {/* STEP 3: Symptoms */}
        {step === "symptoms" && (
          <div style={{ width: "100%", maxWidth: 880 }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 16,
                marginBottom: 32,
              }}
            >
              <button
                onClick={() => setStep("confirm")}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  background: "rgba(255,255,255,0.06)",
                  border: `1px solid ${colors.border}`,
                  color: colors.textSecondary,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <ArrowLeft size={18} />
              </button>
              <div>
                <h2
                  style={{
                    color: colors.textPrimary,
                    fontSize: "clamp(22px,3vw,36px)",
                    fontWeight: 900,
                    margin: 0,
                    letterSpacing: "-0.025em",
                  }}
                >
                  What brings you in today?
                </h2>
                <p
                  style={{
                    color: colors.textSecondary,
                    fontSize: 15,
                    margin: "4px 0 0",
                  }}
                >
                  Select all symptoms that apply — {patient?.full_name}
                </p>
              </div>
            </div>

            {error && (
              <div
                style={{
                  background: "rgba(239,68,68,0.1)",
                  border: "1px solid rgba(239,68,68,0.3)",
                  borderRadius: 12,
                  padding: "14px 20px",
                  color: colors.red,
                  fontSize: 14,
                  marginBottom: 20,
                }}
              >
                {error}
              </div>
            )}

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(4,1fr)",
                gap: 14,
                marginBottom: 28,
              }}
              className="symp-grid"
            >
              {SYMPTOMS.map(({ label, emoji, severity }) => {
                const sel = selectedSymptoms.includes(label);
                const sc = SEVERITY_COLORS[severity];
                return (
                  <button
                    key={label}
                    onClick={() => toggleSymptom(label)}
                    style={{
                      padding: "20px 14px",
                      background: sel ? sc.bg : "rgba(255,255,255,0.03)",
                      border: `2px solid ${sel ? sc.border : colors.border}`,
                      borderRadius: 16,
                      cursor: "pointer",
                      textAlign: "center",
                      transition: "all 0.2s",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 10,
                    }}
                  >
                    <div style={{ fontSize: 36 }}>{emoji}</div>
                    <div
                      style={{
                        color: sel ? sc.text : colors.textSecondary,
                        fontSize: 13,
                        fontWeight: 700,
                        lineHeight: 1.3,
                      }}
                    >
                      {label}
                    </div>
                    {sel && (
                      <div
                        style={{
                          width: 20,
                          height: 20,
                          borderRadius: "50%",
                          background: sc.text,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <CheckCircle2 size={12} color="#000" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
            <style>{`@media(max-width:700px){.symp-grid{grid-template-columns:repeat(2,1fr)!important}}`}</style>

            <GlassCard style={{ padding: "20px", marginBottom: 24 }}>
              <label
                style={{
                  color: colors.textMuted,
                  fontSize: 11,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  display: "block",
                  marginBottom: 10,
                }}
              >
                Additional Details / Other Symptoms
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Describe anything else the care team should know…"
                style={{
                  width: "100%",
                  background: "rgba(255,255,255,0.03)",
                  border: `1px solid ${colors.border}`,
                  borderRadius: 12,
                  padding: "14px 16px",
                  color: colors.textPrimary,
                  fontSize: 15,
                  outline: "none",
                  resize: "none",
                  height: 100,
                  boxSizing: "border-box",
                  fontFamily: "inherit",
                  lineHeight: 1.6,
                }}
              />
            </GlassCard>

            {selectedSymptoms.length > 0 && (
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 8,
                  marginBottom: 20,
                }}
              >
                {selectedSymptoms.map((s) => {
                  const symp = SYMPTOMS.find((x) => x.label === s);
                  const sc = SEVERITY_COLORS[symp?.severity || "moderate"];
                  return (
                    <span
                      key={s}
                      onClick={() => toggleSymptom(s)}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "6px 12px",
                        background: sc.bg,
                        border: `1px solid ${sc.border}`,
                        borderRadius: 100,
                        color: sc.text,
                        fontSize: 12,
                        fontWeight: 600,
                        cursor: "pointer",
                      }}
                    >
                      {s} ×
                    </span>
                  );
                })}
              </div>
            )}

            <button
              onClick={() => {
                setError("");
                submitMutation.mutate();
              }}
              disabled={
                selectedSymptoms.length === 0 || submitMutation.isPending
              }
              style={{
                width: "100%",
                padding: "22px",
                background:
                  selectedSymptoms.length > 0
                    ? colors.cyan
                    : "rgba(255,255,255,0.06)",
                border: "none",
                borderRadius: 16,
                color: selectedSymptoms.length > 0 ? "#000" : colors.textMuted,
                fontSize: 18,
                fontWeight: 900,
                cursor: selectedSymptoms.length > 0 ? "pointer" : "not-allowed",
                transition: "all 0.3s",
                boxShadow:
                  selectedSymptoms.length > 0
                    ? "0 0 40px rgba(6,182,212,0.3)"
                    : "none",
                letterSpacing: "0.02em",
              }}
            >
              {submitMutation.isPending
                ? "Registering for Treatment…"
                : `Register for Treatment (${selectedSymptoms.length} symptom${selectedSymptoms.length !== 1 ? "s" : ""} selected)`}
            </button>
          </div>
        )}

        {/* STEP 4: Success */}
        {step === "success" && (
          <div style={{ textAlign: "center", maxWidth: 580 }}>
            <div
              style={{
                width: 100,
                height: 100,
                borderRadius: "50%",
                background: "rgba(16,185,129,0.15)",
                border: `2px solid rgba(16,185,129,0.4)`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 32px",
                boxShadow: "0 0 60px rgba(16,185,129,0.25)",
              }}
            >
              <CheckCircle2 size={48} color={colors.green} />
            </div>
            <Badge color="green" dot>
              Check-In Complete
            </Badge>
            <h1
              style={{
                color: colors.textPrimary,
                fontSize: "clamp(32px,5vw,56px)",
                fontWeight: 900,
                margin: "20px 0 12px",
                letterSpacing: "-0.03em",
              }}
            >
              You're In the Queue
            </h1>
            <p
              style={{
                color: colors.textSecondary,
                fontSize: 18,
                margin: "0 0 12px",
                lineHeight: 1.7,
              }}
            >
              {patient?.full_name}, your intake has been received and a doctor
              has been notified. Please take a seat in the waiting area.
            </p>
            <p
              style={{
                color: colors.textMuted,
                fontSize: 14,
                margin: "0 0 48px",
              }}
            >
              Your medical history has been automatically loaded for your care
              team.
            </p>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 16,
                maxWidth: 400,
                margin: "0 auto",
              }}
            >
              <GlassCard
                style={{
                  padding: "20px",
                  textAlign: "center",
                  border: `1px solid rgba(16,185,129,0.2)`,
                }}
              >
                <Zap
                  size={24}
                  color={colors.green}
                  style={{ marginBottom: 8 }}
                />
                <div
                  style={{ color: colors.green, fontSize: 18, fontWeight: 800 }}
                >
                  Live
                </div>
                <div style={{ color: colors.textMuted, fontSize: 12 }}>
                  Doctor notified
                </div>
              </GlassCard>
              <GlassCard
                style={{
                  padding: "20px",
                  textAlign: "center",
                  border: `1px solid rgba(6,182,212,0.2)`,
                }}
              >
                <Activity
                  size={24}
                  color={colors.cyan}
                  style={{ marginBottom: 8 }}
                />
                <div
                  style={{ color: colors.cyan, fontSize: 18, fontWeight: 800 }}
                >
                  Active
                </div>
                <div style={{ color: colors.textMuted, fontSize: 12 }}>
                  In queue
                </div>
              </GlassCard>
            </div>
            <button
              onClick={reset}
              style={{
                marginTop: 40,
                padding: "18px 48px",
                background: "transparent",
                border: `1px solid ${colors.border}`,
                borderRadius: 14,
                color: colors.textSecondary,
                fontSize: 15,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Next Patient →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
