"use client";
import React, { useState } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  GlobalStyles,
  GlowDot,
  Input,
  colors,
} from "../../components/VS";
import {
  Activity,
  Heart,
  Stethoscope,
  Shield,
  Building2,
  Globe,
  ChevronRight,
  ArrowLeft,
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";

const ROLES = [
  {
    key: "patient",
    icon: <Heart size={28} color={colors.cyan} />,
    label: "Patient",
    sub: "Access your medical vault & timeline",
    color: colors.cyan,
    href: "/vault",
  },
  {
    key: "doctor",
    icon: <Stethoscope size={28} color={colors.green} />,
    label: "Doctor",
    sub: "Access the clinical command center",
    color: colors.green,
    href: "/doctor",
  },
  {
    key: "nurse",
    icon: <Shield size={28} color={colors.amber} />,
    label: "Nurse",
    sub: "View patient queue & clinical notes",
    color: colors.amber,
    href: "/doctor",
  },
  {
    key: "admin",
    icon: <Building2 size={28} color="#A78BFA" />,
    label: "Hospital Admin",
    sub: "Hospital operations & analytics",
    color: "#A78BFA",
    href: "/doctor",
  },
  {
    key: "enterprise",
    icon: <Globe size={28} color={colors.cyan} />,
    label: "Enterprise Partner",
    sub: "Multi-facility network access",
    color: colors.cyan,
    href: "/doctor",
  },
];

export default function LoginPage() {
  const [selected, setSelected] = useState(null);
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const role = ROLES.find((r) => r.key === selected);

  const patientLogin = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/patients?id=${loginId}`);
      if (!res.ok) throw new Error("Patient not found");
      return res.json();
    },
    onSuccess: (data) => {
      if (typeof window !== "undefined") {
        localStorage.setItem("vital_patient", JSON.stringify(data));
        window.location.href = "/vault";
      }
    },
    onError: () => setError("National ID not found. Please register."),
  });

  const staffLogin = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/auth/staff-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ staff_id: loginId, password }),
      });
      if (!res.ok) throw new Error("Invalid credentials");
      return res.json();
    },
    onSuccess: (data) => {
      if (typeof window !== "undefined") {
        localStorage.setItem("vital_staff", JSON.stringify(data));
        window.location.href = "/doctor";
      }
    },
    onError: () =>
      setError("Invalid credentials. Check Staff ID and password."),
  });

  const handleLogin = () => {
    setError("");
    if (selected === "patient") patientLogin.mutate();
    else staffLogin.mutate();
  };

  const isLoading = patientLogin.isPending || staffLogin.isPending;

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <GlobalStyles />

      {/* Nav */}
      <nav
        style={{
          padding: "20px 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <a
          href="/"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            textDecoration: "none",
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={18} color="#000" />
          </div>
          <span
            style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
          >
            VitalSync
          </span>
        </a>
        <a
          href="/register"
          style={{
            color: colors.cyan,
            fontSize: 14,
            fontWeight: 600,
            textDecoration: "none",
          }}
        >
          No account? Register →
        </a>
      </nav>

      {/* Main */}
      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "40px 32px",
        }}
      >
        <div style={{ width: "100%", maxWidth: selected ? 480 : 860 }}>
          {!selected ? (
            <>
              <div style={{ textAlign: "center", marginBottom: 48 }}>
                <Badge color="cyan" dot>
                  Secure Access
                </Badge>
                <h1
                  style={{
                    color: colors.textPrimary,
                    fontSize: "clamp(28px,4vw,52px)",
                    fontWeight: 900,
                    margin: "20px 0 12px",
                    letterSpacing: "-0.03em",
                  }}
                >
                  Who's Signing In?
                </h1>
                <p style={{ color: colors.textSecondary, fontSize: 16 }}>
                  Select your role to access your personalized VitalSync portal.
                </p>
              </div>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3,1fr)",
                  gap: 16,
                }}
                className="role-grid"
              >
                {ROLES.map((r) => (
                  <GlassCard
                    key={r.key}
                    hover
                    onClick={() => setSelected(r.key)}
                    style={{
                      padding: "28px 22px",
                      cursor: "pointer",
                      textAlign: "center",
                    }}
                  >
                    <div
                      style={{
                        width: 60,
                        height: 60,
                        borderRadius: "50%",
                        background: `${r.color}15`,
                        border: `1px solid ${r.color}30`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        margin: "0 auto 16px",
                      }}
                    >
                      {r.icon}
                    </div>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 16,
                        fontWeight: 700,
                        marginBottom: 6,
                      }}
                    >
                      {r.label}
                    </div>
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 12,
                        lineHeight: 1.5,
                      }}
                    >
                      {r.sub}
                    </div>
                    <div
                      style={{
                        marginTop: 16,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 4,
                        color: r.color,
                        fontSize: 12,
                        fontWeight: 600,
                      }}
                    >
                      Sign In <ChevronRight size={12} />
                    </div>
                  </GlassCard>
                ))}
              </div>
              <style>{`@media(max-width:700px){.role-grid{grid-template-columns:1fr!important}}`}</style>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  setSelected(null);
                  setError("");
                }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  color: colors.textMuted,
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontSize: 14,
                  marginBottom: 32,
                }}
              >
                <ArrowLeft size={16} /> Back to role selection
              </button>
              <GlassCard
                style={{
                  padding: "40px",
                  border: `1px solid rgba(6,182,212,0.2)`,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 16,
                    marginBottom: 32,
                  }}
                >
                  <div
                    style={{
                      width: 52,
                      height: 52,
                      borderRadius: 14,
                      background: `${role.color}15`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {role.icon}
                  </div>
                  <div>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 20,
                        fontWeight: 800,
                      }}
                    >
                      {role.label} Login
                    </div>
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 13,
                        marginTop: 2,
                      }}
                    >
                      {role.sub}
                    </div>
                  </div>
                </div>

                {error && (
                  <div
                    style={{
                      background: "rgba(239,68,68,0.1)",
                      border: "1px solid rgba(239,68,68,0.3)",
                      borderRadius: 10,
                      padding: "12px 16px",
                      color: colors.red,
                      fontSize: 13,
                      marginBottom: 20,
                    }}
                  >
                    {error}
                  </div>
                )}

                <div
                  style={{ display: "flex", flexDirection: "column", gap: 16 }}
                >
                  <div>
                    <label
                      style={{
                        color: colors.textMuted,
                        fontSize: 11,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        display: "block",
                        marginBottom: 8,
                      }}
                    >
                      {selected === "patient" ? "National ID" : "Staff ID"}
                    </label>
                    <Input
                      placeholder={
                        selected === "patient"
                          ? "e.g. ID-001 or P-4821"
                          : "e.g. DR-001"
                      }
                      value={loginId}
                      onChange={(e) => setLoginId(e.target.value)}
                    />
                  </div>
                  {selected !== "patient" && (
                    <div>
                      <label
                        style={{
                          color: colors.textMuted,
                          fontSize: 11,
                          fontWeight: 700,
                          textTransform: "uppercase",
                          letterSpacing: "0.08em",
                          display: "block",
                          marginBottom: 8,
                        }}
                      >
                        Password
                      </label>
                      <Input
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                  )}
                  <CyanButton
                    variant="solid"
                    size="lg"
                    full
                    disabled={isLoading}
                    onClick={handleLogin}
                  >
                    {isLoading
                      ? "Authenticating…"
                      : `Access ${role.label} Portal`}
                  </CyanButton>
                </div>

                {selected !== "patient" && (
                  <div
                    style={{
                      marginTop: 20,
                      padding: "14px 16px",
                      background: "rgba(6,182,212,0.06)",
                      border: `1px solid rgba(6,182,212,0.15)`,
                      borderRadius: 10,
                    }}
                  >
                    <div
                      style={{
                        color: colors.cyan,
                        fontSize: 11,
                        fontWeight: 700,
                        letterSpacing: "0.06em",
                        marginBottom: 8,
                      }}
                    >
                      DEMO CREDENTIALS
                    </div>
                    <div
                      style={{
                        color: colors.textSecondary,
                        fontSize: 12,
                        display: "flex",
                        flexDirection: "column",
                        gap: 4,
                      }}
                    >
                      <span>
                        Doctor:{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          DR-001
                        </span>{" "}
                        /{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          vital123
                        </span>
                      </span>
                      <span>
                        Nurse:{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          NS-001
                        </span>{" "}
                        /{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          vital123
                        </span>
                      </span>
                    </div>
                  </div>
                )}
                {selected === "patient" && (
                  <div
                    style={{
                      marginTop: 20,
                      padding: "14px 16px",
                      background: "rgba(6,182,212,0.06)",
                      border: `1px solid rgba(6,182,212,0.15)`,
                      borderRadius: 10,
                    }}
                  >
                    <div
                      style={{
                        color: colors.cyan,
                        fontSize: 11,
                        fontWeight: 700,
                        letterSpacing: "0.06em",
                        marginBottom: 8,
                      }}
                    >
                      DEMO PATIENTS
                    </div>
                    <div
                      style={{
                        color: colors.textSecondary,
                        fontSize: 12,
                        display: "flex",
                        flexDirection: "column",
                        gap: 4,
                      }}
                    >
                      <span>
                        ID:{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          ID-001
                        </span>{" "}
                        — Alex Rivera
                      </span>
                      <span>
                        ID:{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          ID-002
                        </span>{" "}
                        — Sarah Chen
                      </span>
                      <span>
                        ID:{" "}
                        <span
                          style={{
                            color: colors.textPrimary,
                            fontFamily: "monospace",
                          }}
                        >
                          ID-003
                        </span>{" "}
                        — Marcus Vane
                      </span>
                    </div>
                  </div>
                )}
              </GlassCard>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
