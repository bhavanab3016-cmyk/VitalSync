"use client";
import React, { useState, useEffect } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  GlobalStyles,
  GlowDot,
  Input,
  Textarea,
  colors,
} from "../../components/VS";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  Brain,
  CheckCircle2,
  Clock,
  Database,
  FileText,
  Heart,
  LogOut,
  Monitor,
  Shield,
  Stethoscope,
  User,
  Users,
  Zap,
  ChevronRight,
  TrendingUp,
  Cpu,
  Lock,
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

function ICUBar() {
  const beds = [
    { label: "ICU Beds", used: 14, total: 20, color: colors.amber },
    { label: "Ventilators", used: 6, total: 10, color: colors.cyan },
    { label: "ER Capacity", used: 31, total: 48, color: colors.green },
    { label: "Staff On Shift", used: 18, total: 24, color: "#A78BFA" },
  ];
  return (
    <div
      style={{
        display: "flex",
        gap: 16,
        padding: "10px 24px",
        borderBottom: `1px solid ${colors.border}`,
        background: "rgba(0,0,0,0.25)",
        flexWrap: "wrap",
      }}
    >
      {beds.map((b, i) => (
        <div
          key={i}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            minWidth: 160,
            flex: 1,
          }}
        >
          <span
            style={{
              color: colors.textMuted,
              fontSize: 10,
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.06em",
              whiteSpace: "nowrap",
            }}
          >
            {b.label}
          </span>
          <div
            style={{
              flex: 1,
              height: 4,
              background: "rgba(255,255,255,0.08)",
              borderRadius: 2,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${(b.used / b.total) * 100}%`,
                background: b.color,
                borderRadius: 2,
              }}
            />
          </div>
          <span
            style={{
              color: b.color,
              fontSize: 11,
              fontWeight: 700,
              whiteSpace: "nowrap",
            }}
          >
            {b.used}/{b.total}
          </span>
        </div>
      ))}
    </div>
  );
}

function AIInsight({ visit, history }) {
  const histCount = history?.length || 0;
  const s = (visit?.symptoms || "").toLowerCase();
  const insight = (() => {
    if (s.includes("chest") || s.includes("cardiac") || s.includes("heart"))
      return {
        risk: "CRITICAL",
        color: colors.red,
        riskColor: "red",
        text: `Symptoms indicate potential acute cardiac event. Recommend immediate ECG, troponin levels, and cardiology consultation. ${histCount} prior records cross-referenced. No documented cardiac history found — first-presentation protocol recommended.`,
      };
    if (s.includes("stroke") || s.includes("neuro") || s.includes("seizure"))
      return {
        risk: "CRITICAL",
        color: colors.red,
        riskColor: "red",
        text: `Neurological emergency protocol activated. FAST assessment initiated. Immediate CT scan and neurology consult required. Time-critical intervention window: assess within 15 minutes.`,
      };
    if (s.includes("breath") || s.includes("respiratory"))
      return {
        risk: "HIGH",
        color: colors.amber,
        riskColor: "amber",
        text: `Acute respiratory distress markers present. O2 saturation monitoring recommended. Chest X-ray and spirometry indicated. ${histCount} historical records reviewed — no prior pulmonary conditions flagged.`,
      };
    if (s.includes("fever") || s.includes("temperature"))
      return {
        risk: "MODERATE",
        color: colors.amber,
        riskColor: "amber",
        text: `Systemic inflammatory response suspected. Differential: viral, bacterial, or autoimmune etiology. CBC, CMP, and blood culture recommended. Isolation protocol advisable pending results.`,
      };
    if (s.includes("dizz") || s.includes("headache"))
      return {
        risk: "MODERATE",
        color: colors.amber,
        riskColor: "amber",
        text: `Presenting symptoms consistent with vestibular or vascular origin. BP monitoring and orthostatic vitals recommended. CNS pathology should be excluded given symptom combination.`,
      };
    return {
      risk: "STABLE",
      color: colors.green,
      riskColor: "green",
      text: `Presenting symptoms suggest non-emergency etiology. Standard assessment protocol recommended. ${histCount} historical records available for contextual review. Patient's prior health indicators show stable baseline.`,
    };
  })();

  return (
    <GlassCard
      style={{
        padding: "20px",
        background: "rgba(6,182,212,0.04)",
        border: `1px solid rgba(6,182,212,0.2)`,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          marginBottom: 12,
        }}
      >
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: 8,
            background: "rgba(6,182,212,0.15)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Brain size={16} color={colors.cyan} />
        </div>
        <div style={{ flex: 1 }}>
          <div
            style={{
              color: colors.cyan,
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: "0.1em",
            }}
          >
            AI INTELLIGENT INSIGHT
          </div>
          <div style={{ color: colors.textMuted, fontSize: 10 }}>
            Confidence: 94.7% • {histCount} records cross-referenced
          </div>
        </div>
        <Badge color={insight.riskColor} dot>
          {insight.risk}
        </Badge>
      </div>
      <p
        style={{
          color: colors.textSecondary,
          fontSize: 13,
          lineHeight: 1.7,
          margin: 0,
        }}
      >
        {insight.text}
      </p>
    </GlassCard>
  );
}

function LoginScreen({ onLogin }) {
  const [form, setForm] = useState({ staff_id: "", password: "" });
  const [error, setError] = useState("");

  const loginMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/auth/staff-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Invalid credentials");
      return res.json();
    },
    onSuccess: (data) => {
      if (typeof window !== "undefined")
        localStorage.setItem("vital_staff", JSON.stringify(data));
      onLogin(data);
      setError("");
    },
    onError: () => setError("Invalid Staff ID or password."),
  });

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <GlobalStyles />
      <nav
        style={{
          padding: "18px 40px",
          borderBottom: `1px solid ${colors.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <a
          href="/"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            textDecoration: "none",
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={18} color="#000" />
          </div>
          <span
            style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
          >
            VitalSync Command Center
          </span>
        </a>
        <div style={{ display: "flex", gap: 10 }}>
          <Badge color="green" dot>
            HIPAA Compliant
          </Badge>
          <Badge color="amber">Audit Logging Active</Badge>
        </div>
      </nav>
      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "40px",
        }}
      >
        <div style={{ width: "100%", maxWidth: 460 }}>
          <div style={{ textAlign: "center", marginBottom: 36 }}>
            <div
              style={{
                width: 68,
                height: 68,
                borderRadius: 18,
                background: "rgba(6,182,212,0.12)",
                border: `1px solid rgba(6,182,212,0.3)`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 18px",
              }}
            >
              <Stethoscope size={32} color={colors.cyan} />
            </div>
            <h1
              style={{
                color: colors.textPrimary,
                fontSize: 28,
                fontWeight: 900,
                margin: "0 0 6px",
                letterSpacing: "-0.025em",
              }}
            >
              Doctor Command Center
            </h1>
            <p style={{ color: colors.textMuted, fontSize: 14 }}>
              Authenticated Medical Staff Access Only
            </p>
          </div>
          <GlassCard
            style={{ padding: "32px", border: `1px solid rgba(6,182,212,0.2)` }}
          >
            {error && (
              <div
                style={{
                  background: "rgba(239,68,68,0.1)",
                  border: "1px solid rgba(239,68,68,0.3)",
                  borderRadius: 10,
                  padding: "12px 16px",
                  color: colors.red,
                  fontSize: 13,
                  marginBottom: 18,
                }}
              >
                {error}
              </div>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label
                  style={{
                    color: colors.textMuted,
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: "0.08em",
                    display: "block",
                    marginBottom: 7,
                  }}
                >
                  Staff ID
                </label>
                <Input
                  placeholder="e.g. DR-001"
                  value={form.staff_id}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, staff_id: e.target.value }))
                  }
                />
              </div>
              <div>
                <label
                  style={{
                    color: colors.textMuted,
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: "0.08em",
                    display: "block",
                    marginBottom: 7,
                  }}
                >
                  Password
                </label>
                <Input
                  type="password"
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, password: e.target.value }))
                  }
                />
              </div>
              <CyanButton
                variant="solid"
                size="lg"
                full
                disabled={loginMutation.isPending}
                onClick={() => loginMutation.mutate()}
              >
                {loginMutation.isPending ? "Authenticating…" : "Enter Station"}
              </CyanButton>
            </div>
            <div
              style={{
                marginTop: 18,
                padding: "14px 16px",
                background: "rgba(6,182,212,0.06)",
                border: `1px solid rgba(6,182,212,0.15)`,
                borderRadius: 10,
              }}
            >
              <div
                style={{
                  color: colors.cyan,
                  fontSize: 10,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  marginBottom: 8,
                }}
              >
                DEMO CREDENTIALS
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: 13,
                  }}
                >
                  <span style={{ color: colors.textMuted }}>Doctor:</span>
                  <span
                    style={{
                      color: colors.textPrimary,
                      fontFamily: "monospace",
                    }}
                  >
                    DR-001 / vital123
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: 13,
                  }}
                >
                  <span style={{ color: colors.textMuted }}>Nurse:</span>
                  <span
                    style={{
                      color: colors.textPrimary,
                      fontFamily: "monospace",
                    }}
                  >
                    NS-001 / vital123
                  </span>
                </div>
              </div>
            </div>
          </GlassCard>
          <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
            {[
              ["HIPAA", colors.green],
              ["SOC 2", colors.cyan],
              ["Audit Trail", colors.amber],
            ].map(([l, c]) => (
              <div
                key={l}
                style={{
                  flex: 1,
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  justifyContent: "center",
                  padding: "10px",
                  background: "rgba(255,255,255,0.03)",
                  borderRadius: 10,
                  border: `1px solid ${colors.border}`,
                }}
              >
                <GlowDot color={c} size={6} />
                <span
                  style={{
                    color: colors.textMuted,
                    fontSize: 11,
                    fontWeight: 600,
                  }}
                >
                  {l}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Dashboard({ staff, onLogout }) {
  const [selected, setSelected] = useState(null);
  const [diagnosis, setDiagnosis] = useState("");
  const [prescriptions, setPrescriptions] = useState("");
  const [tab, setTab] = useState("history");
  const queryClient = useQueryClient();

  const { data: queue = [] } = useQuery({
    queryKey: ["queue"],
    queryFn: async () => {
      const res = await fetch("/api/visits?status=waiting");
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    refetchInterval: 4000,
  });

  const { data: history = [] } = useQuery({
    queryKey: ["history", selected?.patient_id],
    queryFn: async () => {
      const res = await fetch(`/api/timeline?patientId=${selected.patient_id}`);
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!selected,
  });

  // NEW: fetch real per-patient clinical profile
  const { data: profile = null } = useQuery({
    queryKey: ["profile", selected?.patient_id],
    queryFn: async () => {
      const res = await fetch(`/api/profile?patientId=${selected.patient_id}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!selected,
  });

  const diagnosisMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/records", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patient_id: selected.patient_id,
          visit_id: selected.id,
          diagnosis,
          prescriptions,
        }),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["queue"]);
      queryClient.invalidateQueries(["history", selected?.patient_id]);
      setSelected(null);
      setDiagnosis("");
      setPrescriptions("");
    },
  });

  const urgencyColor = (v) => {
    const s = (v.symptoms || "").toLowerCase();
    if (
      s.includes("chest") ||
      s.includes("stroke") ||
      s.includes("bleed") ||
      s.includes("cardiac")
    )
      return colors.red;
    if (
      s.includes("breath") ||
      s.includes("fever") ||
      s.includes("dizz") ||
      s.includes("head")
    )
      return colors.amber;
    return colors.green;
  };

  const waitTime = (ca) => {
    const mins = Math.floor((Date.now() - new Date(ca)) / 60000);
    return mins < 60 ? `${mins}m` : `${Math.floor(mins / 60)}h ${mins % 60}m`;
  };

  const symptomsArr =
    selected?.symptoms
      ?.split(",")
      .map((s) => s.trim())
      .filter(Boolean) || [];

  return (
    <div
      style={{
        background: colors.bg,
        height: "100vh",
        fontFamily: "'Inter',sans-serif",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <GlobalStyles />

      {/* Top Nav */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 24px",
          borderBottom: `1px solid ${colors.border}`,
          background: "rgba(0,0,0,0.3)",
          flexShrink: 0,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: 8,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={16} color="#000" />
          </div>
          <div>
            <div
              style={{
                color: colors.textPrimary,
                fontWeight: 800,
                fontSize: 15,
              }}
            >
              VitalSync Command Center
            </div>
            <div style={{ color: colors.textMuted, fontSize: 10 }}>
              Clinical Operations Platform
            </div>
          </div>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            flexWrap: "wrap",
          }}
        >
          <Badge color="green" dot>
            Live Sync
          </Badge>
          <Badge color="amber">Audit Active</Badge>
          <Badge color="cyan">HIPAA</Badge>
          <div style={{ width: 1, height: 20, background: colors.border }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div
              style={{
                width: 30,
                height: 30,
                borderRadius: "50%",
                background: "rgba(6,182,212,0.15)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <User size={14} color={colors.cyan} />
            </div>
            <div>
              <div
                style={{
                  color: colors.textPrimary,
                  fontSize: 12,
                  fontWeight: 700,
                }}
              >
                {staff.name}
              </div>
              <div style={{ color: colors.textMuted, fontSize: 10 }}>
                {staff.role}
              </div>
            </div>
          </div>
          <button
            onClick={onLogout}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 5,
              color: colors.textMuted,
              background: "none",
              border: "none",
              cursor: "pointer",
              fontSize: 12,
              padding: "6px 8px",
            }}
          >
            <LogOut size={13} /> Out
          </button>
        </div>
      </div>

      <ICUBar />

      {/* Body */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* Sidebar */}
        <div
          style={{
            width: 280,
            borderRight: `1px solid ${colors.border}`,
            display: "flex",
            flexDirection: "column",
            flexShrink: 0,
          }}
        >
          <div
            style={{
              padding: "14px 18px",
              borderBottom: `1px solid ${colors.border}`,
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <span
                style={{
                  color: colors.textPrimary,
                  fontSize: 13,
                  fontWeight: 700,
                }}
              >
                Patient Queue
              </span>
              <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <GlowDot color={colors.green} />
                <span
                  style={{ color: colors.green, fontSize: 10, fontWeight: 700 }}
                >
                  LIVE
                </span>
              </div>
            </div>
            <span style={{ color: colors.textMuted, fontSize: 11 }}>
              {queue.length} waiting
            </span>
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: "8px" }}>
            {queue.length === 0 ? (
              <div style={{ padding: "28px 16px", textAlign: "center" }}>
                <CheckCircle2
                  size={28}
                  color={colors.green}
                  style={{ margin: "0 auto 10px" }}
                />
                <p style={{ color: colors.textMuted, fontSize: 12 }}>
                  Queue clear.
                </p>
              </div>
            ) : (
              queue.map((v) => {
                const uc = urgencyColor(v);
                const active = selected?.id === v.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => {
                      setSelected(v);
                      setDiagnosis("");
                      setPrescriptions("");
                      setTab("history");
                    }}
                    style={{
                      width: "100%",
                      textAlign: "left",
                      padding: "12px",
                      borderRadius: 10,
                      border: active
                        ? `1px solid ${colors.cyan}`
                        : `1px solid transparent`,
                      background: active
                        ? "rgba(6,182,212,0.08)"
                        : "transparent",
                      cursor: "pointer",
                      marginBottom: 3,
                      borderLeft: `3px solid ${active ? colors.cyan : uc}`,
                      transition: "all 0.2s",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        marginBottom: 4,
                      }}
                    >
                      <span
                        style={{
                          color: colors.textPrimary,
                          fontSize: 12,
                          fontWeight: 700,
                        }}
                      >
                        {v.full_name || v.patient_id}
                      </span>
                      <div
                        style={{
                          width: 7,
                          height: 7,
                          borderRadius: "50%",
                          background: uc,
                          boxShadow: `0 0 5px ${uc}`,
                          flexShrink: 0,
                          marginTop: 2,
                        }}
                      />
                    </div>
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 10,
                        marginBottom: 6,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {v.symptoms}
                    </div>
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 6 }}
                    >
                      <Badge color="amber">Wait</Badge>
                      <span style={{ color: colors.textMuted, fontSize: 9 }}>
                        {waitTime(v.created_at)}
                      </span>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          <div
            style={{
              padding: "14px 18px",
              borderTop: `1px solid ${colors.border}`,
            }}
          >
            <div
              style={{
                color: colors.textMuted,
                fontSize: 9,
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                marginBottom: 10,
              }}
            >
              Today's Stats
            </div>
            {[
              ["Treated", "18", colors.green],
              ["Avg Wait", "8.4m", colors.cyan],
              ["Critical", "3", colors.red],
            ].map(([l, v, c]) => (
              <div
                key={l}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: 7,
                }}
              >
                <span style={{ color: colors.textMuted, fontSize: 11 }}>
                  {l}
                </span>
                <span style={{ color: c, fontSize: 13, fontWeight: 800 }}>
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Main Panel */}
        <div style={{ flex: 1, overflowY: "auto" }}>
          {!selected ? (
            <div
              style={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                opacity: 0.35,
              }}
            >
              <Database
                size={52}
                color={colors.textMuted}
                style={{ marginBottom: 14 }}
              />
              <h2
                style={{
                  color: colors.textPrimary,
                  fontSize: 24,
                  fontWeight: 800,
                  margin: "0 0 8px",
                }}
              >
                Station Ready
              </h2>
              <p
                style={{
                  color: colors.textMuted,
                  fontSize: 14,
                  textAlign: "center",
                  maxWidth: 300,
                }}
              >
                Select a patient from the live queue to begin clinical review.
              </p>
            </div>
          ) : (
            <div style={{ padding: "22px 28px" }}>
              {/* Header */}
              <div
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: 14,
                  marginBottom: 20,
                }}
              >
                <button
                  onClick={() => setSelected(null)}
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: "50%",
                    background: "rgba(255,255,255,0.06)",
                    border: `1px solid ${colors.border}`,
                    color: colors.textMuted,
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                    marginTop: 4,
                  }}
                >
                  <ArrowLeft size={15} />
                </button>
                <div
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius: "50%",
                    background: "rgba(6,182,212,0.12)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  <User size={22} color={colors.cyan} />
                </div>
                <div>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span
                      style={{
                        color: colors.textPrimary,
                        fontSize: 20,
                        fontWeight: 900,
                      }}
                    >
                      {selected.full_name || selected.patient_id}
                    </span>
                    <Badge color="cyan">{selected.patient_id}</Badge>
                    <Badge color="amber">Waiting</Badge>
                  </div>
                  <div style={{ color: colors.textMuted, fontSize: 12 }}>
                    Intake: {new Date(selected.created_at).toLocaleTimeString()}{" "}
                    • Wait: {waitTime(selected.created_at)}
                  </div>
                </div>
              </div>

              {/* Symptoms */}
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 7,
                  marginBottom: 18,
                }}
              >
                {symptomsArr.map((s, i) => {
                  const sl = s.toLowerCase();
                  const c =
                    sl.includes("chest") ||
                    sl.includes("stroke") ||
                    sl.includes("bleed")
                      ? "red"
                      : sl.includes("breath") || sl.includes("fever")
                        ? "amber"
                        : "cyan";
                  return (
                    <Badge key={i} color={c}>
                      {s}
                    </Badge>
                  );
                })}
              </div>

              {/* AI */}
              <div style={{ marginBottom: 20 }}>
                <AIInsight visit={selected} history={history} />
              </div>

              {/* Tabs */}
              <div
                style={{
                  display: "flex",
                  gap: 4,
                  background: "rgba(255,255,255,0.04)",
                  borderRadius: 100,
                  padding: "3px",
                  marginBottom: 20,
                  width: "fit-content",
                }}
              >
                {[
                  ["history", "Cloud History"],
                  ["diagnosis", "Diagnosis Interface"],
                ].map(([id, label]) => (
                  <button
                    key={id}
                    onClick={() => setTab(id)}
                    style={{
                      padding: "8px 18px",
                      borderRadius: 100,
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: "pointer",
                      border: "none",
                      background: tab === id ? colors.cyan : "transparent",
                      color: tab === id ? "#000" : colors.textSecondary,
                      transition: "all 0.2s",
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>

              {/* History */}
              {tab === "history" && (
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 18,
                  }}
                  className="hist-grid"
                >
                  <div>
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 10,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        marginBottom: 12,
                      }}
                    >
                      Pre-recorded Cloud History
                    </div>
                    {history.length === 0 ? (
                      <GlassCard
                        style={{ padding: "20px", textAlign: "center" }}
                      >
                        <p style={{ color: colors.textMuted, fontSize: 12 }}>
                          No prior cloud records for this patient.
                        </p>
                      </GlassCard>
                    ) : (
                      history.map((item, i) => (
                        <GlassCard
                          key={i}
                          style={{ padding: "12px 14px", marginBottom: 8 }}
                        >
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              marginBottom: 5,
                            }}
                          >
                            <Badge
                              color={
                                item.type === "Hospital Visit"
                                  ? "cyan"
                                  : item.type === "Emergency Triage"
                                    ? "red"
                                    : "green"
                              }
                            >
                              {item.type}
                            </Badge>
                            <span
                              style={{ color: colors.textMuted, fontSize: 10 }}
                            >
                              {new Date(item.date).toLocaleDateString()}
                            </span>
                          </div>
                          <div
                            style={{
                              color: colors.textPrimary,
                              fontSize: 12,
                              fontWeight: 600,
                              marginBottom: 3,
                            }}
                          >
                            {item.description}
                          </div>
                          {item.detail && (
                            <div
                              style={{
                                color: colors.textMuted,
                                fontSize: 11,
                                fontStyle: "italic",
                              }}
                            >
                              "{item.detail}"
                            </div>
                          )}
                        </GlassCard>
                      ))
                    )}
                  </div>
                  <div>
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 10,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        marginBottom: 12,
                      }}
                    >
                      Clinical Profile
                    </div>
                    <GlassCard style={{ padding: "18px" }}>
                      {[
                        ["Allergies", profile?.allergies, colors.red],
                        ["Blood Type", profile?.blood_type, colors.cyan],
                        [
                          "Chronic Conditions",
                          profile?.chronic_conditions,
                          colors.amber,
                        ],
                        [
                          "Current Medications",
                          profile?.current_medications,
                          colors.green,
                        ],
                        [
                          "Last Hospitalization",
                          profile?.last_hospitalization,
                          colors.textSecondary,
                        ],
                        ["Insurance", profile?.insurance, colors.textSecondary],
                        [
                          "Emergency Contact",
                          profile?.emergency_contact,
                          colors.textSecondary,
                        ],
                      ].map(([l, v, c], i) => (
                        <div
                          key={l}
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            padding: "9px 0",
                            borderBottom:
                              i < 6 ? `1px solid ${colors.border}` : "none",
                            gap: 12,
                          }}
                        >
                          <span
                            style={{
                              color: colors.textMuted,
                              fontSize: 12,
                              flexShrink: 0,
                            }}
                          >
                            {l}
                          </span>
                          <span
                            style={{
                              color: v ? c : colors.textMuted,
                              fontSize: 12,
                              fontWeight: v ? 600 : 400,
                              textAlign: "right",
                              fontStyle: v ? "normal" : "italic",
                            }}
                          >
                            {v || "Not on record"}
                          </span>
                        </div>
                      ))}
                      {profile?.notes && (
                        <div
                          style={{
                            marginTop: 12,
                            padding: "10px 12px",
                            background: "rgba(6,182,212,0.06)",
                            border: `1px solid rgba(6,182,212,0.15)`,
                            borderRadius: 8,
                          }}
                        >
                          <div
                            style={{
                              color: colors.cyan,
                              fontSize: 9,
                              fontWeight: 700,
                              letterSpacing: "0.08em",
                              marginBottom: 4,
                            }}
                          >
                            CLINICAL NOTES
                          </div>
                          <div
                            style={{
                              color: colors.textSecondary,
                              fontSize: 11,
                              lineHeight: 1.5,
                            }}
                          >
                            {profile.notes}
                          </div>
                        </div>
                      )}
                    </GlassCard>
                  </div>
                </div>
              )}
              <style>{`@media(max-width:800px){.hist-grid{grid-template-columns:1fr!important}}`}</style>

              {/* Diagnosis */}
              {tab === "diagnosis" && (
                <div>
                  <GlassCard
                    style={{
                      padding: "24px",
                      border: `1px solid rgba(6,182,212,0.15)`,
                    }}
                  >
                    <div
                      style={{
                        color: colors.textMuted,
                        fontSize: 10,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        marginBottom: 18,
                      }}
                    >
                      Clinical Review & Diagnosis
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 18,
                      }}
                    >
                      <div>
                        <label
                          style={{
                            color: colors.textMuted,
                            fontSize: 10,
                            fontWeight: 700,
                            textTransform: "uppercase",
                            letterSpacing: "0.06em",
                            display: "block",
                            marginBottom: 7,
                          }}
                        >
                          Diagnosis & Clinical Findings
                        </label>
                        <Textarea
                          placeholder="Enter diagnosis, clinical findings, and assessment…"
                          value={diagnosis}
                          onChange={(e) => setDiagnosis(e.target.value)}
                          rows={5}
                        />
                      </div>
                      <div>
                        <label
                          style={{
                            color: colors.textMuted,
                            fontSize: 10,
                            fontWeight: 700,
                            textTransform: "uppercase",
                            letterSpacing: "0.06em",
                            display: "block",
                            marginBottom: 7,
                          }}
                        >
                          Prescriptions, Treatment Plan & Follow-up
                        </label>
                        <Textarea
                          placeholder="List medications, dosages, care instructions, follow-up schedule…"
                          value={prescriptions}
                          onChange={(e) => setPrescriptions(e.target.value)}
                          rows={4}
                          style={{ fontFamily: "monospace" }}
                        />
                      </div>
                      <CyanButton
                        variant="solid"
                        size="lg"
                        full
                        disabled={
                          !diagnosis.trim() || diagnosisMutation.isPending
                        }
                        onClick={() => diagnosisMutation.mutate()}
                      >
                        <CheckCircle2 size={17} />
                        {diagnosisMutation.isPending
                          ? "Saving to Cloud…"
                          : "Finalize & Save to Cloud"}
                      </CyanButton>
                    </div>
                  </GlassCard>
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr 1fr",
                      gap: 12,
                      marginTop: 14,
                    }}
                  >
                    {[
                      ["HIPAA Logged", colors.green],
                      ["Audit Trail", colors.amber],
                      ["Cloud Synced", colors.cyan],
                    ].map(([l, c]) => (
                      <div
                        key={l}
                        style={{
                          padding: "10px 14px",
                          background: "rgba(255,255,255,0.03)",
                          borderRadius: 8,
                          border: `1px solid ${colors.border}`,
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                        }}
                      >
                        <GlowDot color={c} size={6} />
                        <span
                          style={{
                            color: colors.textMuted,
                            fontSize: 11,
                            fontWeight: 600,
                          }}
                        >
                          {l}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function DoctorApp() {
  const [staff, setStaff] = useState(null);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("vital_staff");
      if (saved) setStaff(JSON.parse(saved));
      setChecked(true);
    }
  }, []);

  if (!checked)
    return <div style={{ background: colors.bg, minHeight: "100vh" }} />;
  if (!staff) return <LoginScreen onLogin={(s) => setStaff(s)} />;
  return (
    <Dashboard
      staff={staff}
      onLogout={() => {
        if (typeof window !== "undefined")
          localStorage.removeItem("vital_staff");
        setStaff(null);
      }}
    />
  );
}
