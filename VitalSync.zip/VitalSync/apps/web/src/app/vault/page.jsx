"use client";
import React, { useState, useEffect, useRef } from "react";
import {
  GlassCard,
  Badge,
  CyanButton,
  GlobalStyles,
  GlowDot,
  Input,
  colors,
} from "../../components/VS";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ChevronRight,
  Clock,
  Database,
  FileText,
  Heart,
  LogOut,
  MapPin,
  Phone,
  QrCode,
  Shield,
  Stethoscope,
  Upload,
  User,
  Zap,
  Plus,
  X,
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const TAB = ({ id, label, active, onClick }) => (
  <button
    onClick={onClick}
    style={{
      padding: "10px 20px",
      borderRadius: "100px",
      fontSize: 13,
      fontWeight: 600,
      cursor: "pointer",
      border: "none",
      transition: "all 0.2s",
      background: active ? colors.cyan : "transparent",
      color: active ? "#000" : colors.textSecondary,
    }}
  >
    {label}
  </button>
);

function SosOverlay({ patient, onClose }) {
  const [count, setCount] = useState(5);
  const [fired, setFired] = useState(false);

  const triageMutation = useMutation({
    mutationFn: async (coords) => {
      const res = await fetch("/api/triage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ patient_id: patient.national_id, ...coords }),
      });
      return res.json();
    },
  });

  useEffect(() => {
    if (count > 0) {
      const t = setTimeout(() => setCount((c) => c - 1), 1000);
      return () => clearTimeout(t);
    } else if (!fired) {
      setFired(true);
      if (typeof navigator !== "undefined" && navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) =>
            triageMutation.mutate({
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
            }),
          () => triageMutation.mutate({ latitude: null, longitude: null }),
        );
      } else {
        triageMutation.mutate({ latitude: null, longitude: null });
      }
    }
  }, [count, fired]);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "#1a0000",
        zIndex: 9999,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: 32,
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(circle at center, rgba(239,68,68,0.3) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          width: 100,
          height: 100,
          borderRadius: "50%",
          background: "rgba(239,68,68,0.2)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 32,
          animation: "sosGlow 1.5s ease-in-out infinite",
        }}
      >
        <AlertTriangle size={48} color={colors.red} />
      </div>
      {fired ? (
        <>
          <div
            style={{
              color: colors.red,
              fontSize: "clamp(28px,5vw,48px)",
              fontWeight: 900,
              textAlign: "center",
              marginBottom: 16,
            }}
          >
            EMERGENCY ALERT SENT
          </div>
          <p
            style={{
              color: "rgba(255,255,255,0.7)",
              fontSize: 16,
              textAlign: "center",
              maxWidth: 420,
              lineHeight: 1.7,
              marginBottom: 16,
            }}
          >
            Your GPS location and full medical history have been broadcast to
            the nearest emergency facility. Help is on the way.
          </p>
          <div
            style={{
              background: "rgba(239,68,68,0.1)",
              border: "1px solid rgba(239,68,68,0.3)",
              borderRadius: 12,
              padding: "12px 20px",
              marginBottom: 32,
              textAlign: "center",
            }}
          >
            <div
              style={{
                color: colors.red,
                fontSize: 12,
                fontWeight: 700,
                letterSpacing: "0.06em",
              }}
            >
              PATIENT IDENTITY BROADCAST
            </div>
            <div
              style={{
                color: "rgba(255,255,255,0.9)",
                fontSize: 14,
                marginTop: 4,
              }}
            >
              {patient.full_name} — {patient.national_id}
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              padding: "16px 40px",
              background: "rgba(255,255,255,0.1)",
              border: "1px solid rgba(255,255,255,0.2)",
              borderRadius: "100px",
              color: "#fff",
              fontSize: 15,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Close
          </button>
        </>
      ) : (
        <>
          <div
            style={{
              color: "#fff",
              fontSize: "clamp(20px,4vw,36px)",
              fontWeight: 900,
              textAlign: "center",
              marginBottom: 8,
            }}
          >
            EMERGENCY SOS TRIGGERED
          </div>
          <p
            style={{
              color: "rgba(255,255,255,0.6)",
              fontSize: 16,
              textAlign: "center",
              marginBottom: 40,
            }}
          >
            Broadcasting identity + location in…
          </p>
          <div
            style={{
              fontSize: "clamp(80px,15vw,140px)",
              fontWeight: 900,
              color: colors.red,
              lineHeight: 1,
              marginBottom: 48,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {count}
          </div>
          <button
            onClick={onClose}
            style={{
              padding: "16px 48px",
              background: "rgba(255,255,255,0.08)",
              border: "1px solid rgba(255,255,255,0.2)",
              borderRadius: "100px",
              color: "#fff",
              fontSize: 16,
              fontWeight: 700,
              cursor: "pointer",
              letterSpacing: "0.04em",
            }}
          >
            CANCEL ALERT
          </button>
        </>
      )}
      <style>{`@keyframes sosGlow{0%,100%{box-shadow:0 0 40px rgba(239,68,68,0.4)}50%{box-shadow:0 0 80px rgba(239,68,68,0.9)}}`}</style>
    </div>
  );
}

function LoginScreen({ onLogin }) {
  const [nationalId, setNationalId] = useState("");
  const [regForm, setRegForm] = useState({
    national_id: "",
    full_name: "",
    email: "",
    dob: "",
    gender: "",
  });
  const [view, setView] = useState("login"); // login | register | confirm
  const [found, setFound] = useState(null);
  const [error, setError] = useState("");

  const searchMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/patients?id=${nationalId}`);
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
    onSuccess: (data) => {
      setFound(data);
      setView("confirm");
    },
    onError: () => setError("National ID not found. Please register."),
  });

  const registerMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/patients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(regForm),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Registration failed");
      return data;
    },
    onSuccess: (data) => onLogin(data),
    onError: (e) => setError(e.message),
  });

  const isSearching = searchMutation.isPending;
  const isRegistering = registerMutation.isPending;

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <GlobalStyles />
      <nav
        style={{
          padding: "20px 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <a
          href="/"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            textDecoration: "none",
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg,#06B6D4,#0284C7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Activity size={18} color="#000" />
          </div>
          <span
            style={{ color: colors.textPrimary, fontWeight: 800, fontSize: 17 }}
          >
            VitalSync Vault
          </span>
        </a>
        <Badge color="green" dot>
          Encrypted • Cloud-Synced
        </Badge>
      </nav>

      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "32px",
        }}
      >
        <div style={{ width: "100%", maxWidth: 440 }}>
          {view === "login" && (
            <GlassCard
              style={{
                padding: "40px",
                border: `1px solid rgba(6,182,212,0.2)`,
              }}
            >
              <div style={{ textAlign: "center", marginBottom: 32 }}>
                <div
                  style={{
                    width: 64,
                    height: 64,
                    borderRadius: "50%",
                    background: "rgba(6,182,212,0.12)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 20px",
                  }}
                >
                  <Heart size={30} color={colors.cyan} />
                </div>
                <h1
                  style={{
                    color: colors.textPrimary,
                    fontSize: 24,
                    fontWeight: 800,
                    margin: "0 0 8px",
                  }}
                >
                  Access Your Vault
                </h1>
                <p style={{ color: colors.textMuted, fontSize: 14 }}>
                  Enter your National ID to access your lifelong medical record
                </p>
              </div>
              {error && (
                <div
                  style={{
                    background: "rgba(239,68,68,0.1)",
                    border: "1px solid rgba(239,68,68,0.3)",
                    borderRadius: 10,
                    padding: "12px 16px",
                    color: colors.red,
                    fontSize: 13,
                    marginBottom: 20,
                  }}
                >
                  {error}
                </div>
              )}
              <div
                style={{ display: "flex", flexDirection: "column", gap: 14 }}
              >
                <div>
                  <label
                    style={{
                      color: colors.textMuted,
                      fontSize: 11,
                      fontWeight: 700,
                      textTransform: "uppercase",
                      letterSpacing: "0.08em",
                      display: "block",
                      marginBottom: 8,
                    }}
                  >
                    National ID
                  </label>
                  <Input
                    placeholder="e.g. ID-001"
                    value={nationalId}
                    onChange={(e) => setNationalId(e.target.value)}
                  />
                </div>
                <CyanButton
                  variant="solid"
                  size="lg"
                  full
                  disabled={isSearching}
                  onClick={() => {
                    setError("");
                    searchMutation.mutate();
                  }}
                >
                  {isSearching ? "Verifying Identity…" : "Access Medical Vault"}
                </CyanButton>
              </div>
              <div
                style={{
                  margin: "24px 0",
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                }}
              >
                <div
                  style={{ flex: 1, height: 1, background: colors.border }}
                />
                <span style={{ color: colors.textMuted, fontSize: 12 }}>
                  NEW PATIENT
                </span>
                <div
                  style={{ flex: 1, height: 1, background: colors.border }}
                />
              </div>
              <CyanButton
                variant="outline"
                size="md"
                full
                onClick={() => {
                  setView("register");
                  setError("");
                }}
              >
                Create Medical Identity
              </CyanButton>
              <div
                style={{
                  marginTop: 20,
                  padding: "12px 16px",
                  background: "rgba(6,182,212,0.05)",
                  borderRadius: 10,
                  textAlign: "center",
                }}
              >
                <span style={{ color: colors.textMuted, fontSize: 12 }}>
                  Demo:{" "}
                </span>
                {["ID-001", "ID-002", "ID-003"].map((id) => (
                  <button
                    key={id}
                    onClick={() => setNationalId(id)}
                    style={{
                      background: "none",
                      border: "none",
                      color: colors.cyan,
                      fontSize: 12,
                      fontFamily: "monospace",
                      cursor: "pointer",
                      marginLeft: 8,
                      fontWeight: 600,
                    }}
                  >
                    {id}
                  </button>
                ))}
              </div>
            </GlassCard>
          )}

          {view === "confirm" && found && (
            <GlassCard
              style={{
                padding: "40px",
                textAlign: "center",
                border: `1px solid rgba(6,182,212,0.2)`,
              }}
            >
              <div
                style={{
                  width: 72,
                  height: 72,
                  borderRadius: "50%",
                  background: "rgba(6,182,212,0.12)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  margin: "0 auto 24px",
                }}
              >
                <User size={32} color={colors.cyan} />
              </div>
              <div
                style={{
                  color: colors.textMuted,
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  marginBottom: 8,
                }}
              >
                Is this you?
              </div>
              <h2
                style={{
                  color: colors.textPrimary,
                  fontSize: 26,
                  fontWeight: 800,
                  margin: "0 0 4px",
                }}
              >
                {found.full_name}
              </h2>
              <p
                style={{
                  color: colors.textMuted,
                  fontSize: 14,
                  margin: "0 0 4px",
                }}
              >
                ID: {found.national_id}
              </p>
              <p
                style={{
                  color: colors.textMuted,
                  fontSize: 14,
                  margin: "0 0 32px",
                }}
              >
                DOB: {new Date(found.dob).toLocaleDateString()}
              </p>
              <div
                style={{ display: "flex", flexDirection: "column", gap: 12 }}
              >
                <CyanButton
                  variant="solid"
                  size="lg"
                  full
                  onClick={() => onLogin(found)}
                >
                  Yes, Access My Vault
                </CyanButton>
                <CyanButton
                  variant="ghost"
                  size="md"
                  full
                  onClick={() => {
                    setView("login");
                    setFound(null);
                    setError("");
                    setNationalId("");
                  }}
                >
                  Not me — Go back
                </CyanButton>
              </div>
            </GlassCard>
          )}

          {view === "register" && (
            <GlassCard
              style={{
                padding: "40px",
                border: `1px solid rgba(6,182,212,0.2)`,
              }}
            >
              <button
                onClick={() => {
                  setView("login");
                  setError("");
                }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  color: colors.textMuted,
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontSize: 13,
                  marginBottom: 24,
                }}
              >
                <ArrowLeft size={15} /> Back
              </button>
              <h2
                style={{
                  color: colors.textPrimary,
                  fontSize: 20,
                  fontWeight: 800,
                  margin: "0 0 6px",
                }}
              >
                Create Medical Identity
              </h2>
              <p
                style={{
                  color: colors.textMuted,
                  fontSize: 13,
                  margin: "0 0 28px",
                  lineHeight: 1.5,
                }}
              >
                Your National ID becomes your universal identifier across every
                VitalSync partner hospital.
              </p>
              {error && (
                <div
                  style={{
                    background: "rgba(239,68,68,0.1)",
                    border: "1px solid rgba(239,68,68,0.3)",
                    borderRadius: 10,
                    padding: "12px 16px",
                    color: colors.red,
                    fontSize: 13,
                    marginBottom: 20,
                  }}
                >
                  {error}
                </div>
              )}
              <div
                style={{ display: "flex", flexDirection: "column", gap: 14 }}
              >
                {[
                  ["National ID", "national_id", "e.g. ID-007", "text"],
                  ["Full Name", "full_name", "Legal full name", "text"],
                  ["Email", "email", "your@email.com", "email"],
                ].map(([l, k, ph, t]) => (
                  <div key={k}>
                    <label
                      style={{
                        color: colors.textMuted,
                        fontSize: 11,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        display: "block",
                        marginBottom: 7,
                      }}
                    >
                      {l}
                    </label>
                    <Input
                      type={t}
                      placeholder={ph}
                      value={regForm[k]}
                      onChange={(e) =>
                        setRegForm((p) => ({ ...p, [k]: e.target.value }))
                      }
                    />
                  </div>
                ))}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 12,
                  }}
                >
                  <div>
                    <label
                      style={{
                        color: colors.textMuted,
                        fontSize: 11,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        display: "block",
                        marginBottom: 7,
                      }}
                    >
                      Date of Birth
                    </label>
                    <Input
                      type="date"
                      value={regForm.dob}
                      onChange={(e) =>
                        setRegForm((p) => ({ ...p, dob: e.target.value }))
                      }
                    />
                  </div>
                  <div>
                    <label
                      style={{
                        color: colors.textMuted,
                        fontSize: 11,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.08em",
                        display: "block",
                        marginBottom: 7,
                      }}
                    >
                      Gender
                    </label>
                    <select
                      value={regForm.gender}
                      onChange={(e) =>
                        setRegForm((p) => ({ ...p, gender: e.target.value }))
                      }
                      style={{
                        width: "100%",
                        background: "rgba(255,255,255,0.04)",
                        border: `1px solid ${colors.border}`,
                        borderRadius: 12,
                        padding: "13px 12px",
                        color: colors.textPrimary,
                        fontSize: 14,
                        outline: "none",
                      }}
                    >
                      <option value="">Select</option>
                      {[
                        "Male",
                        "Female",
                        "Non-binary",
                        "Prefer not to say",
                      ].map((g) => (
                        <option key={g} value={g}>
                          {g}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <CyanButton
                  variant="solid"
                  size="lg"
                  full
                  disabled={isRegistering}
                  onClick={() => {
                    setError("");
                    registerMutation.mutate();
                  }}
                >
                  {isRegistering ? "Creating…" : "Create My Identity"}
                </CyanButton>
              </div>
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
}

const VAULT_DOCS = [
  {
    name: "Annual Blood Work 2025",
    type: "PDF",
    size: "1.2 MB",
    date: "Oct 12, 2025",
    icon: "🩸",
    color: colors.red,
  },
  {
    name: "Chest X-Ray",
    type: "DICOM",
    size: "45 MB",
    date: "Aug 05, 2025",
    icon: "🫁",
    color: colors.cyan,
  },
  {
    name: "Cardiology Prescription",
    type: "PDF",
    size: "0.3 MB",
    date: "Jul 18, 2025",
    icon: "💊",
    color: colors.amber,
  },
  {
    name: "Discharge Summary — St. Claire",
    type: "PDF",
    size: "0.8 MB",
    date: "Jun 02, 2025",
    icon: "🏥",
    color: colors.green,
  },
  {
    name: "Insurance Authorization",
    type: "PDF",
    size: "0.4 MB",
    date: "May 15, 2025",
    icon: "📋",
    color: "#A78BFA",
  },
  {
    name: "MRI Scan — Brain",
    type: "DICOM",
    size: "128 MB",
    date: "Mar 28, 2025",
    icon: "🧠",
    color: colors.cyan,
  },
];

function Dashboard({ patient, onLogout }) {
  const [tab, setTab] = useState("timeline");
  const [showSOS, setShowSOS] = useState(false);
  const queryClient = useQueryClient();

  const { data: timeline = [] } = useQuery({
    queryKey: ["timeline", patient.national_id],
    queryFn: async () => {
      const res = await fetch(`/api/timeline?patientId=${patient.national_id}`);
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    refetchInterval: 10000,
  });

  const age = patient.dob
    ? Math.floor(
        (Date.now() - new Date(patient.dob)) / (1000 * 60 * 60 * 24 * 365.25),
      )
    : "—";

  const typeColors = {
    "Hospital Visit": colors.cyan,
    "Clinical Record": colors.green,
    "Emergency Triage": colors.red,
    Prescription: colors.amber,
  };
  const typeIcons = {
    "Hospital Visit": <Stethoscope size={14} />,
    "Clinical Record": <FileText size={14} />,
    "Emergency Triage": <AlertTriangle size={14} />,
    Prescription: <Zap size={14} />,
  };

  return (
    <div
      style={{
        background: colors.bg,
        minHeight: "100vh",
        fontFamily: "'Inter',sans-serif",
      }}
    >
      <GlobalStyles />
      {showSOS && (
        <SosOverlay patient={patient} onClose={() => setShowSOS(false)} />
      )}

      {/* Top Nav */}
      <nav
        style={{
          position: "sticky",
          top: 0,
          zIndex: 100,
          background: "rgba(2,6,23,0.95)",
          backdropFilter: "blur(20px)",
          borderBottom: `1px solid ${colors.border}`,
          padding: "0 24px",
        }}
      >
        <div
          style={{
            maxWidth: 680,
            margin: "0 auto",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            height: 60,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                width: 30,
                height: 30,
                borderRadius: 8,
                background: "linear-gradient(135deg,#06B6D4,#0284C7)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Activity size={16} color="#000" />
            </div>
            <span
              style={{
                color: colors.textPrimary,
                fontWeight: 800,
                fontSize: 15,
              }}
            >
              Patient Vault
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Badge color="green" dot>
              Secure
            </Badge>
            <button
              onClick={onLogout}
              style={{
                background: "none",
                border: "none",
                color: colors.textMuted,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 13,
              }}
            >
              <LogOut size={15} /> Sign Out
            </button>
          </div>
        </div>
      </nav>

      <div
        style={{ maxWidth: 680, margin: "0 auto", padding: "24px 24px 80px" }}
      >
        {/* Profile Header */}
        <GlassCard
          style={{
            padding: "24px",
            marginBottom: 16,
            border: `1px solid rgba(6,182,212,0.15)`,
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              marginBottom: 20,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: "50%",
                  background: "rgba(6,182,212,0.15)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <User size={26} color={colors.cyan} />
              </div>
              <div>
                <div
                  style={{
                    color: colors.textPrimary,
                    fontSize: 20,
                    fontWeight: 800,
                  }}
                >
                  {patient.full_name}
                </div>
                <div
                  style={{
                    color: colors.textMuted,
                    fontSize: 13,
                    marginTop: 2,
                  }}
                >
                  ID: {patient.national_id} • Age: {age} •{" "}
                  {patient.gender || "—"}
                </div>
              </div>
            </div>
            <Badge color="green" dot>
              Active
            </Badge>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr 1fr",
              gap: 12,
            }}
          >
            {[
              {
                label: "Health Score",
                value: "Stable",
                sub: "88/100",
                color: colors.green,
              },
              {
                label: "Active Alerts",
                value: "0 Critical",
                sub: "All Clear",
                color: colors.cyan,
              },
              {
                label: "Cloud Records",
                value: `${timeline.length + VAULT_DOCS.length}`,
                sub: "Files synced",
                color: colors.amber,
              },
            ].map((s, i) => (
              <div
                key={i}
                style={{
                  background: "rgba(255,255,255,0.03)",
                  borderRadius: 12,
                  padding: "14px",
                }}
              >
                <div
                  style={{
                    color: colors.textMuted,
                    fontSize: 10,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                  }}
                >
                  {s.label}
                </div>
                <div
                  style={{
                    color: s.color,
                    fontSize: 16,
                    fontWeight: 800,
                    marginTop: 4,
                  }}
                >
                  {s.value}
                </div>
                <div
                  style={{
                    color: colors.textMuted,
                    fontSize: 11,
                    marginTop: 2,
                  }}
                >
                  {s.sub}
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* SOS Button */}
        <button
          onClick={() => setShowSOS(true)}
          style={{
            width: "100%",
            padding: "16px",
            background: "linear-gradient(135deg, #EF4444, #DC2626)",
            border: "none",
            borderRadius: 14,
            cursor: "pointer",
            marginBottom: 20,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
            boxShadow: "0 0 30px rgba(239,68,68,0.35)",
            animation: "glow 3s ease-in-out infinite",
          }}
        >
          <AlertTriangle size={22} color="#fff" />
          <span
            style={{
              color: "#fff",
              fontSize: 17,
              fontWeight: 900,
              letterSpacing: "0.04em",
            }}
          >
            EMERGENCY SOS
          </span>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              background: "rgba(255,255,255,0.15)",
              borderRadius: 8,
              padding: "4px 10px",
            }}
          >
            <MapPin size={13} color="#fff" />
            <span style={{ color: "#fff", fontSize: 11, fontWeight: 700 }}>
              GPS • Auto-Alert
            </span>
          </div>
        </button>
        <style>{`@keyframes glow{0%,100%{box-shadow:0 0 30px rgba(239,68,68,0.35)}50%{box-shadow:0 0 50px rgba(239,68,68,0.6)}}`}</style>

        {/* Emergency Quick Actions */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: 10,
            marginBottom: 24,
          }}
        >
          {[
            {
              icon: <QrCode size={18} />,
              label: "Emergency QR",
              color: colors.amber,
            },
            {
              icon: <Phone size={18} />,
              label: "Call Ambulance",
              color: colors.red,
            },
            {
              icon: <MapPin size={18} />,
              label: "Nearest Hospital",
              color: colors.cyan,
            },
          ].map((a, i) => (
            <GlassCard
              key={i}
              hover
              onClick={() => {}}
              style={{
                padding: "14px 12px",
                cursor: "pointer",
                textAlign: "center",
              }}
            >
              <div style={{ color: a.color, marginBottom: 6 }}>{a.icon}</div>
              <div
                style={{
                  color: colors.textSecondary,
                  fontSize: 11,
                  fontWeight: 600,
                }}
              >
                {a.label}
              </div>
            </GlassCard>
          ))}
        </div>

        {/* Tabs */}
        <div
          style={{
            display: "flex",
            gap: 4,
            background: "rgba(255,255,255,0.04)",
            borderRadius: 100,
            padding: "4px",
            marginBottom: 24,
          }}
        >
          {[
            ["timeline", "Medical Timeline"],
            ["vault", "Cloud Vault"],
            ["emergency", "Emergency"],
          ].map(([id, label]) => (
            <TAB
              key={id}
              id={id}
              label={label}
              active={tab === id}
              onClick={() => setTab(id)}
            />
          ))}
        </div>

        {/* Timeline Tab */}
        {tab === "timeline" && (
          <div>
            {timeline.length === 0 ? (
              <GlassCard style={{ padding: "40px", textAlign: "center" }}>
                <Clock
                  size={32}
                  color={colors.textMuted}
                  style={{ margin: "0 auto 12px" }}
                />
                <p style={{ color: colors.textMuted, fontSize: 14 }}>
                  No timeline events yet. Check in at a hospital kiosk to begin
                  your record.
                </p>
              </GlassCard>
            ) : (
              <div style={{ position: "relative" }}>
                <div
                  style={{
                    position: "absolute",
                    left: 20,
                    top: 0,
                    bottom: 0,
                    width: 1,
                    background: `linear-gradient(to bottom, ${colors.cyan}60, transparent)`,
                  }}
                />
                {timeline.map((item, i) => {
                  const c = typeColors[item.type] || colors.cyan;
                  return (
                    <div
                      key={i}
                      style={{
                        display: "flex",
                        gap: 20,
                        marginBottom: 20,
                        position: "relative",
                      }}
                    >
                      <div
                        style={{
                          width: 40,
                          height: 40,
                          borderRadius: "50%",
                          background: `${c}15`,
                          border: `1px solid ${c}40`,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                          color: c,
                          zIndex: 1,
                        }}
                      >
                        {typeIcons[item.type] || <Activity size={14} />}
                      </div>
                      <GlassCard
                        hover
                        style={{ flex: 1, padding: "16px 18px" }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "flex-start",
                            justifyContent: "space-between",
                            marginBottom: 6,
                          }}
                        >
                          <Badge
                            color={
                              c === colors.red
                                ? "red"
                                : c === colors.green
                                  ? "green"
                                  : c === colors.amber
                                    ? "amber"
                                    : "cyan"
                            }
                          >
                            {item.type}
                          </Badge>
                          <span
                            style={{ color: colors.textMuted, fontSize: 11 }}
                          >
                            {new Date(item.date).toLocaleDateString()}
                          </span>
                        </div>
                        <div
                          style={{
                            color: colors.textPrimary,
                            fontSize: 14,
                            fontWeight: 600,
                            marginBottom: 4,
                          }}
                        >
                          {item.description}
                        </div>
                        {item.detail && (
                          <div
                            style={{
                              color: colors.textSecondary,
                              fontSize: 12,
                              lineHeight: 1.5,
                              fontStyle: "italic",
                            }}
                          >
                            "{item.detail}"
                          </div>
                        )}
                      </GlassCard>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Cloud Vault Tab */}
        {tab === "vault" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 4,
              }}
            >
              <span
                style={{
                  color: colors.textMuted,
                  fontSize: 12,
                  fontWeight: 600,
                }}
              >
                {VAULT_DOCS.length} files stored
              </span>
              <CyanButton variant="outline" size="sm">
                <Upload size={14} /> Upload
              </CyanButton>
            </div>
            {VAULT_DOCS.map((d, i) => (
              <GlassCard
                key={i}
                hover
                style={{ padding: "16px 18px", cursor: "pointer" }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <div
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 11,
                      background: `${d.color}15`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 22,
                      flexShrink: 0,
                    }}
                  >
                    {d.icon}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 14,
                        fontWeight: 600,
                        marginBottom: 3,
                      }}
                    >
                      {d.name}
                    </div>
                    <div style={{ color: colors.textMuted, fontSize: 11 }}>
                      {d.date} • {d.type} • {d.size}
                    </div>
                  </div>
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <Badge color="cyan">{d.type}</Badge>
                    <ChevronRight size={16} color={colors.textMuted} />
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        )}

        {/* Emergency Tab */}
        {tab === "emergency" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <GlassCard
              style={{
                padding: "24px",
                border: `1px solid rgba(239,68,68,0.2)`,
              }}
            >
              <div
                style={{
                  color: colors.red,
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  marginBottom: 16,
                }}
              >
                EMERGENCY FEATURES
              </div>
              {[
                {
                  icon: <QrCode size={20} color={colors.amber} />,
                  title: "Lock-Screen Emergency QR",
                  desc: "Scan to access your critical medical info without unlocking — for first responders.",
                },
                {
                  icon: <Phone size={20} color={colors.red} />,
                  title: "One-Tap Ambulance Call",
                  desc: "Instantly dials emergency services with your location pre-loaded.",
                },
                {
                  icon: <Heart size={20} color={colors.red} />,
                  title: "Family Auto-Alert System",
                  desc: "Designated emergency contacts notified automatically on SOS activation.",
                },
                {
                  icon: <MapPin size={20} color={colors.cyan} />,
                  title: "Live Hospital Routing",
                  desc: "GPS-based routing to the nearest suitable facility based on your symptoms and history.",
                },
              ].map((f, i) => (
                <div
                  key={i}
                  style={{
                    display: "flex",
                    gap: 14,
                    alignItems: "flex-start",
                    marginBottom: i < 3 ? 18 : 0,
                    paddingBottom: i < 3 ? 18 : 0,
                    borderBottom: i < 3 ? `1px solid ${colors.border}` : "none",
                  }}
                >
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 10,
                      background: "rgba(239,68,68,0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {f.icon}
                  </div>
                  <div>
                    <div
                      style={{
                        color: colors.textPrimary,
                        fontSize: 14,
                        fontWeight: 600,
                        marginBottom: 4,
                      }}
                    >
                      {f.title}
                    </div>
                    <div
                      style={{
                        color: colors.textSecondary,
                        fontSize: 12,
                        lineHeight: 1.5,
                      }}
                    >
                      {f.desc}
                    </div>
                  </div>
                </div>
              ))}
            </GlassCard>
            <GlassCard
              style={{
                padding: "24px",
                border: `1px solid rgba(245,158,11,0.2)`,
              }}
            >
              <div
                style={{
                  color: colors.amber,
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  marginBottom: 12,
                }}
              >
                FRIEND / FAMILY EMERGENCY MODE
              </div>
              <p
                style={{
                  color: colors.textSecondary,
                  fontSize: 13,
                  lineHeight: 1.6,
                  margin: "0 0 16px",
                }}
              >
                If a patient is unconscious or unable to act — a friend, family
                member, or bystander can enter this app, input symptoms, and
                trigger emergency routing using the patient's medical history.
              </p>
              <CyanButton
                variant="outline"
                size="md"
                style={{
                  borderColor: "rgba(245,158,11,0.5)",
                  color: colors.amber,
                }}
              >
                Activate Emergency Mode
              </CyanButton>
            </GlassCard>
          </div>
        )}
      </div>
    </div>
  );
}

export default function VaultPage() {
  const [patient, setPatient] = useState(null);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("vital_patient");
      if (saved) setPatient(JSON.parse(saved));
      setChecked(true);
    }
  }, []);

  if (!checked)
    return <div style={{ background: colors.bg, minHeight: "100vh" }} />;

  if (!patient)
    return (
      <LoginScreen
        onLogin={(p) => {
          if (typeof window !== "undefined")
            localStorage.setItem("vital_patient", JSON.stringify(p));
          setPatient(p);
        }}
      />
    );

  return (
    <Dashboard
      patient={patient}
      onLogout={() => {
        if (typeof window !== "undefined")
          localStorage.removeItem("vital_patient");
        setPatient(null);
      }}
    />
  );
}
