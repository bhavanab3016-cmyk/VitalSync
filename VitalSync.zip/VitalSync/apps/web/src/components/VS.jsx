// VitalSync Premium Dark UI Component Library
import React from "react";

export const colors = {
  bg: "#020617",
  bgCard: "rgba(255,255,255,0.03)",
  bgCardHover: "rgba(255,255,255,0.06)",
  border: "rgba(255,255,255,0.08)",
  borderHover: "rgba(6,182,212,0.4)",
  cyan: "#06B6D4",
  cyanGlow: "rgba(6,182,212,0.15)",
  cyanDim: "rgba(6,182,212,0.6)",
  red: "#EF4444",
  redGlow: "rgba(239,68,68,0.15)",
  green: "#10B981",
  greenGlow: "rgba(16,185,129,0.15)",
  amber: "#F59E0B",
  amberGlow: "rgba(245,158,11,0.15)",
  textPrimary: "#F1F5F9",
  textSecondary: "#94A3B8",
  textMuted: "#475569",
};

// Glass Card
export function GlassCard({
  children,
  className = "",
  style = {},
  hover = false,
  glow = false,
  glowColor = colors.cyanGlow,
  onClick,
}) {
  const [hovered, setHovered] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered && hover ? colors.bgCardHover : colors.bgCard,
        border: `1px solid ${hovered && hover ? colors.borderHover : colors.border}`,
        borderRadius: "16px",
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        boxShadow: glow ? `0 0 40px ${glowColor}` : "none",
        cursor: onClick ? "pointer" : "default",
        ...style,
      }}
      className={className}
    >
      {children}
    </div>
  );
}

// Cyan Badge/Pill
export function Badge({ children, color = "cyan", dot = false }) {
  const palettes = {
    cyan: {
      bg: "rgba(6,182,212,0.1)",
      border: "rgba(6,182,212,0.3)",
      text: "#06B6D4",
    },
    red: {
      bg: "rgba(239,68,68,0.1)",
      border: "rgba(239,68,68,0.3)",
      text: "#EF4444",
    },
    green: {
      bg: "rgba(16,185,129,0.1)",
      border: "rgba(16,185,129,0.3)",
      text: "#10B981",
    },
    amber: {
      bg: "rgba(245,158,11,0.1)",
      border: "rgba(245,158,11,0.3)",
      text: "#F59E0B",
    },
    slate: {
      bg: "rgba(71,85,105,0.2)",
      border: "rgba(71,85,105,0.4)",
      text: "#94A3B8",
    },
  };
  const p = palettes[color] || palettes.cyan;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        background: p.bg,
        border: `1px solid ${p.border}`,
        color: p.text,
        borderRadius: "100px",
        padding: "3px 10px",
        fontSize: "11px",
        fontWeight: 600,
        letterSpacing: "0.02em",
      }}
    >
      {dot && (
        <span
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            background: p.text,
            display: "inline-block",
          }}
        />
      )}
      {children}
    </span>
  );
}

// CyanButton
export function CyanButton({
  children,
  onClick,
  full = false,
  size = "md",
  variant = "solid",
  style = {},
  disabled = false,
  type = "button",
}) {
  const [hovered, setHovered] = React.useState(false);
  const sizes = {
    sm: { padding: "8px 18px", fontSize: "13px" },
    md: { padding: "11px 24px", fontSize: "14px" },
    lg: { padding: "14px 32px", fontSize: "15px" },
    xl: { padding: "18px 40px", fontSize: "16px" },
  };
  const s = sizes[size] || sizes.md;
  const baseStyle = {
    borderRadius: "12px",
    fontWeight: 600,
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
    width: full ? "100%" : "auto",
    border: "none",
    letterSpacing: "0.01em",
    opacity: disabled ? 0.5 : 1,
    ...s,
  };
  if (variant === "solid") {
    return (
      <button
        type={type}
        disabled={disabled}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={onClick}
        style={{
          ...baseStyle,
          background: hovered ? "#0891B2" : colors.cyan,
          color: "#000",
          boxShadow: hovered
            ? `0 0 30px rgba(6,182,212,0.5)`
            : `0 0 20px rgba(6,182,212,0.25)`,
          ...style,
        }}
      >
        {children}
      </button>
    );
  }
  if (variant === "outline") {
    return (
      <button
        type={type}
        disabled={disabled}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={onClick}
        style={{
          ...baseStyle,
          background: hovered ? "rgba(6,182,212,0.1)" : "transparent",
          color: colors.cyan,
          border: `1px solid ${hovered ? colors.cyan : "rgba(6,182,212,0.4)"}`,
          ...style,
        }}
      >
        {children}
      </button>
    );
  }
  if (variant === "ghost") {
    return (
      <button
        type={type}
        disabled={disabled}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={onClick}
        style={{
          ...baseStyle,
          background: hovered ? "rgba(255,255,255,0.05)" : "transparent",
          color: colors.textSecondary,
          ...style,
        }}
      >
        {children}
      </button>
    );
  }
  if (variant === "danger") {
    return (
      <button
        type={type}
        disabled={disabled}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={onClick}
        style={{
          ...baseStyle,
          background: hovered ? "#DC2626" : colors.red,
          color: "#fff",
          boxShadow: hovered
            ? `0 0 30px rgba(239,68,68,0.6)`
            : `0 0 20px rgba(239,68,68,0.3)`,
          ...style,
        }}
      >
        {children}
      </button>
    );
  }
}

// Divider
export function Divider({ style = {} }) {
  return (
    <div
      style={{ height: 1, background: colors.border, width: "100%", ...style }}
    />
  );
}

// Section Title
export function SectionLabel({ children }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "8px",
        marginBottom: "12px",
      }}
    >
      <div style={{ width: 20, height: 1, background: colors.cyan }} />
      <span
        style={{
          color: colors.cyan,
          fontSize: "11px",
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
        }}
      >
        {children}
      </span>
      <div style={{ width: 20, height: 1, background: colors.cyan }} />
    </div>
  );
}

// GlowDot — pulsing indicator
export function GlowDot({ color = colors.green, size = 8 }) {
  return (
    <span
      style={{
        display: "inline-block",
        width: size,
        height: size,
        borderRadius: "50%",
        background: color,
        boxShadow: `0 0 ${size * 2}px ${color}`,
        animation: "pulse 2s cubic-bezier(0.4,0,0.6,1) infinite",
      }}
    />
  );
}

// Input
export function Input({
  placeholder,
  value,
  onChange,
  type = "text",
  style = {},
  icon,
}) {
  const [focused, setFocused] = React.useState(false);
  return (
    <div style={{ position: "relative" }}>
      {icon && (
        <div
          style={{
            position: "absolute",
            left: 14,
            top: "50%",
            transform: "translateY(-50%)",
            color: colors.textMuted,
            pointerEvents: "none",
          }}
        >
          {icon}
        </div>
      )}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: "100%",
          background: "rgba(255,255,255,0.04)",
          border: `1px solid ${focused ? colors.cyan : colors.border}`,
          borderRadius: "12px",
          padding: icon ? "13px 16px 13px 44px" : "13px 16px",
          color: colors.textPrimary,
          fontSize: "14px",
          outline: "none",
          transition: "all 0.2s",
          boxShadow: focused ? `0 0 0 3px rgba(6,182,212,0.1)` : "none",
          boxSizing: "border-box",
          ...style,
        }}
      />
    </div>
  );
}

// Textarea
export function Textarea({
  placeholder,
  value,
  onChange,
  rows = 4,
  style = {},
}) {
  const [focused, setFocused] = React.useState(false);
  return (
    <textarea
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      rows={rows}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      style={{
        width: "100%",
        background: "rgba(255,255,255,0.04)",
        border: `1px solid ${focused ? colors.cyan : colors.border}`,
        borderRadius: "12px",
        padding: "13px 16px",
        color: colors.textPrimary,
        fontSize: "14px",
        outline: "none",
        transition: "all 0.2s",
        boxShadow: focused ? `0 0 0 3px rgba(6,182,212,0.1)` : "none",
        resize: "vertical",
        boxSizing: "border-box",
        fontFamily: "inherit",
        ...style,
      }}
    />
  );
}

// Stat Card
export function StatCard({ label, value, sub, color = colors.cyan, icon }) {
  return (
    <GlassCard style={{ padding: "20px 24px" }}>
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
        }}
      >
        <div>
          <div
            style={{
              color: colors.textMuted,
              fontSize: "11px",
              fontWeight: 600,
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              marginBottom: "8px",
            }}
          >
            {label}
          </div>
          <div
            style={{ color, fontSize: "28px", fontWeight: 800, lineHeight: 1 }}
          >
            {value}
          </div>
          {sub && (
            <div
              style={{
                color: colors.textMuted,
                fontSize: "12px",
                marginTop: "6px",
              }}
            >
              {sub}
            </div>
          )}
        </div>
        {icon && (
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: "10px",
              background: `rgba(6,182,212,0.1)`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color,
            }}
          >
            {icon}
          </div>
        )}
      </div>
    </GlassCard>
  );
}

// Nav Link
export function NavLink({ href, children, active = false }) {
  const [hovered, setHovered] = React.useState(false);
  return (
    <a
      href={href}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        color: active || hovered ? colors.textPrimary : colors.textSecondary,
        fontSize: "14px",
        fontWeight: 500,
        textDecoration: "none",
        transition: "color 0.2s",
        padding: "6px 0",
      }}
    >
      {children}
    </a>
  );
}

// Global CSS for animations (injected as style tag)
export function GlobalStyles() {
  return (
    <style>{`
      @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
      @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      @keyframes shimmer { 0% { background-position: -1000px 0; } 100% { background-position: 1000px 0; } }
      @keyframes glow { 0%, 100% { box-shadow: 0 0 20px rgba(6,182,212,0.3); } 50% { box-shadow: 0 0 40px rgba(6,182,212,0.6); } }
      @keyframes sosGlow { 0%, 100% { box-shadow: 0 0 30px rgba(239,68,68,0.4); } 50% { box-shadow: 0 0 60px rgba(239,68,68,0.8); } }
      * { box-sizing: border-box; }
      ::placeholder { color: rgba(148,163,184,0.5) !important; }
      ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: rgba(6,182,212,0.3); border-radius: 10px; }
      select option { background: #0F172A; color: #F1F5F9; }
    `}</style>
  );
}
