import React, { useState, useEffect } from "react";
import {
  Activity,
  Shield,
  AlertCircle,
  Clock,
  FileText,
  MapPin,
  LogOut,
  User,
  Calendar,
  CreditCard,
  Plus,
  Search,
  CheckCircle2,
  ChevronRight,
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

// --- Shared Components ---

export function Pill({ children, variant = "outline", icon: Icon }) {
  const baseClass =
    "rounded-full px-3 py-1 text-xs font-medium inline-flex items-center gap-1.5 transition-colors";
  const variants = {
    outline: "bg-white border border-[#E5E7EB] text-[#374151]",
    soft: "bg-[#EFF6FF] text-[#2563EB]",
    status: "bg-white border border-[#E5E7EB] text-[#374151]",
  };

  return (
    <div className={`${baseClass} ${variants[variant]}`}>
      {variant === "status" && (
        <div className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
      )}
      {Icon && <Icon size={12} />}
      {children}
    </div>
  );
}

export function Card({ children, title, subtitle, footer, className = "" }) {
  return (
    <div
      className={`bg-white rounded-xl border border-[#E5E7EB] p-6 ${className}`}
    >
      {(title || subtitle) && (
        <div className="mb-4">
          {title && (
            <h3 className="text-[#111827] font-semibold text-lg">{title}</h3>
          )}
          {subtitle && (
            <p className="text-[#6B7280] text-sm mt-1">{subtitle}</p>
          )}
        </div>
      )}
      {children}
      {footer && (
        <div className="mt-4 pt-4 border-t border-[#E5E7EB]">{footer}</div>
      )}
    </div>
  );
}

export function Tabs({ tabs, activeTab, onChange }) {
  return (
    <div className="flex border-b border-[#E5E7EB] w-full overflow-x-auto">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`px-4 pb-3 text-sm transition-all whitespace-nowrap -mb-[1px] ${
            activeTab === tab.id
              ? "text-[#111827] font-medium border-b-2 border-[#2563EB]"
              : "text-[#6B7280] font-normal border-b-2 border-transparent hover:text-[#374151]"
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}

export function RingProgress({ value, color = "#EA580C" }) {
  const radius = 12;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg className="w-8 h-8 -rotate-90">
        <circle
          className="stroke-[#F3F4F6]"
          strokeWidth="3"
          fill="transparent"
          r={radius}
          cx="16"
          cy="16"
        />
        <circle
          className="transition-all duration-500 ease-in-out"
          stroke={color}
          strokeWidth="3"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          fill="transparent"
          r={radius}
          cx="16"
          cy="16"
        />
      </svg>
      <span className="absolute text-[10px] font-semibold text-[#111827]">
        {value}%
      </span>
    </div>
  );
}

// --- App Layout ---

export default function VitalSyncLayout({ children, mode = "patient" }) {
  return <div className="min-h-screen bg-[#F9FAFB] font-inter">{children}</div>;
}
